import SwiftUI
import Charts
import Combine

enum AppTheme {
    static let wine = Color(red: 0.65, green: 0.05, blue: 0.15)
    static let appBackground = Color(red: 0.96, green: 0.96, blue: 0.98)
    static let cardBackground = Color.white
    static let softOrange = Color(red: 0.95, green: 0.50, blue: 0.10)
    static let softGreen = Color(red: 0.13, green: 0.65, blue: 0.36)
    static let mutedText = Color.gray
    static let cardCornerRadius: CGFloat = 20
}

extension View {
    func modernCard() -> some View {
        self
            .background(AppTheme.cardBackground)
            .cornerRadius(AppTheme.cardCornerRadius)
            .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
    }
}

// MARK: - Store Name Generator

enum StoreNameGenerator {
    private static let names = [
        "Abarrotes Juan", "Tienda Los 3 Hermanos", "Mini Super Lupita",
        "Abarrotes El Güero", "Tienda Doña Chayo", "El Recreo de Martínez",
        "Abarrotes La Esquina", "Super Toño", "Tienda El Farolito",
        "Abarrotes Don Memo", "La Tiendita de Rosita", "El Rincón de Pepe",
        "Abarrotes La Paloma", "Tienda Los Compadres", "Mini Súper El Refugio",
        "Abarrotes Hernández", "La Bodega de Carmen", "Tienda El Oasis",
        "Abarrotes El Progreso", "Super Don Lupe", "Tienda La Esperanza",
        "Abarrotes El Nido", "Minisuper Los Primos", "Tienda Don Beto",
        "La Tiendita del Barrio", "Abarrotes La Fe", "Super Ramírez",
        "Tienda El Manantial", "Abarrotes Los Reyes", "El Changarro de Güicho",
        "Tienda Doña Meche", "Abarrotes El Paraíso", "Super La Colonia",
        "Tienda Los Amigos", "Abarrotes El Trebol", "Mini Súper Familia Cruz",
        "La Tiendita de Nachito", "Abarrotes Villa Norte", "Tienda El Pino",
        "Super Don Chico", "Abarrotes La Unión", "Tienda Señora Elvira",
        "El Changarro de Lalo", "Abarrotes El Roble", "Tienda Los Sánchez",
        "Mini Súper El Sauce", "Abarrotes Don Polo", "Tienda La Herradura",
        "Super Los Comales", "Abarrotes El Girasol"
    ]

    static func name(for customerId: String) -> String {
        let hash = customerId.unicodeScalars.reduce(0) { $0 &+ Int($1.value) }
        return names[abs(hash) % names.count]
    }
}

// MARK: - Model

struct StoreClient: Identifiable, Codable, Hashable {
    let id: String
    let name: String
    let customerId: String
    let calmonth: String
    let territoryD: String
    let comercialSubchannelD: String
    let customerSize: String
    let coolers: Int
    let doors: Int
    let transactions: Int
    let uniBoxesSoldM: Double
    let riskPercentage: Double
    let riskLevel: String
    let segment: String

    var storeName: String { StoreNameGenerator.name(for: customerId) }

    var riskColor: Color {
        if riskPercentage >= 80 { return AppTheme.wine }
        if riskPercentage >= 50 { return AppTheme.softOrange }
        return AppTheme.softGreen
    }

    var isCritical: Bool { riskPercentage >= 80 }
}

// MARK: - Data Loader

struct ClientDataLoader {
    static func loadClients() -> [StoreClient] {
        guard let url = Bundle.main.url(forResource: "churn_predictions", withExtension: "json") else {
            print("No se encontró churn_predictions.json"); return []
        }
        do {
            let data = try Data(contentsOf: url)
            return try JSONDecoder().decode([StoreClient].self, from: data)
        } catch { print("Error leyendo JSON:", error); return [] }
    }
}

// MARK: - Enums

enum RiskFilter: String, CaseIterable {
    case highest = "Mayor Riesgo"
    case lowest  = "Menor Riesgo"
}

// ── CHANGE 1: Removed .profile tab ──────────────────────────────────────────
enum AppTab { case home, dashboards, reports }

// MARK: - Main Tab

struct MainTabView: View {
    @State private var selectedTab: AppTab = .home
    private let clients = ClientDataLoader.loadClients()

    var body: some View {
        TabView(selection: $selectedTab) {
            DashboardView(clients: clients, selectedTab: $selectedTab)
                .tabItem { Image(systemName: "house.fill"); Text("Inicio") }
                .tag(AppTab.home)

            ExecutiveDashboardView(clients: clients)
                .tabItem { Image(systemName: "square.grid.2x2.fill"); Text("Dash") }
                .tag(AppTab.dashboards)

            ReportesView(clients: clients)
                .tabItem { Image(systemName: "folder.fill"); Text("Reportes") }
                .tag(AppTab.reports)
        }
        .tint(AppTheme.wine)
    }
}

// MARK: - Agent Context

enum AgentContext {
    case home(clients: [StoreClient])
    case storeList(filtered: [StoreClient], levelFilter: String, month: String)
    case clientDetail(client: StoreClient)
    case dashboard(clients: [StoreClient])

    var prompt: String { buildPrompt() }

    private func buildPrompt() -> String {
        switch self {
        case .home(let clients):      return AgentContext.homePrompt(clients)
        case .storeList(let f, let lvl, let month): return AgentContext.storeListPrompt(f, lvl, month)
        case .clientDetail(let c):    return AgentContext.clientPrompt(c)
        case .dashboard(let clients): return AgentContext.dashPrompt(clients)
        }
    }

    private static func homePrompt(_ clients: [StoreClient]) -> String {
        let total   = clients.count
        let critArr = clients.filter { $0.riskPercentage >= 80 }
        let medArr  = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }
        let avg     = clients.map { $0.uniBoxesSoldM }.reduce(0, +) / Double(max(total, 1))
        let volC    = Int(Double(critArr.count) * avg * 0.80)
        let volM    = Int(Double(medArr.count)  * avg * 0.40)
        let volT    = volC + volM
        let groups  = Dictionary(grouping: clients, by: { $0.territoryD })
        var sorted: [(n: String, a: Double)] = []
        for (key, vals) in groups {
            sorted.append((n: key, a: vals.map { $0.riskPercentage }.reduce(0, +) / Double(vals.count)))
        }
        sorted.sort { $0.a > $1.a }
        let top3 = sorted.prefix(3).map { $0.n }.joined(separator: ", ")
        var p = "Eres agente experto en churn del Canal Tradicional de bebidas en Mexico.\n"
        p += "Dame un briefing ULTRA CORTO en exactamente 3 bullets.\n"
        p += "DATOS:\n- Total tiendas: \(total)\n"
        p += "- Criticas (>=80%): \(critArr.count) vol ~\(volC) cajas\n"
        p += "- Medias (50-79%): \(medArr.count) vol ~\(volM) cajas\n"
        p += "- Volumen total en riesgo: ~\(volT) cajas\n"
        p += "- Top 3 territorios: \(top3)\n"
        p += "Formato exacto:\n• [dato critico con numero]\n• [territorio con numero]\n• [accion hoy]\n"
        p += "Maximo 10 palabras por bullet. Sin emojis. Solo texto plano."
        return p
    }

    private static func storeListPrompt(_ filtered: [StoreClient], _ levelFilter: String, _ month: String) -> String {
        let total = filtered.count
        let critN = filtered.filter { $0.riskPercentage >= 80 }.count
        let medN  = filtered.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
        let avgB  = filtered.map { $0.uniBoxesSoldM }.reduce(0, +) / Double(max(total, 1))
        let vol   = Int(Double(critN) * avgB * 0.80 + Double(medN) * avgB * 0.40)
        let groups = Dictionary(grouping: filtered, by: { $0.territoryD })
        var sorted: [(n: String, a: Double)] = []
        for (key, vals) in groups {
            sorted.append((n: key, a: vals.map { $0.riskPercentage }.reduce(0, +) / Double(vals.count)))
        }
        sorted.sort { $0.a > $1.a }
        let topTerr = sorted.prefix(3).map { "\($0.n) (\(String(format:"%.0f",$0.a))%)" }.joined(separator: ", ")
        var p = "Eres agente experto en churn del Canal Tradicional.\n"
        p += "FILTRO: Nivel \"\(levelFilter)\" Mes \(month)\n"
        p += "Tiendas: \(total), Criticas: \(critN), Medias: \(medN)\n"
        p += "Vol riesgo: ~\(vol) cajas. Territorios: \(topTerr)\n"
        p += "2 oraciones: estado del filtro, accion concreta. Sin emojis. Max 45 palabras."
        return p
    }

    private static func clientPrompt(_ c: StoreClient) -> String {
        let drop    = c.uniBoxesSoldM < 1 ? "sin ventas" : "\(Int(c.uniBoxesSoldM)) cajas"
        let riskStr = String(format: "%.1f", c.riskPercentage)
        var p = "Eres agente experto en churn del Canal Tradicional.\n"
        p += "Territorio: \(c.territoryD), Subcanal: \(c.comercialSubchannelD), Tamano: \(c.customerSize)\n"
        p += "Riesgo: \(riskStr)% \(c.riskLevel), Segmento: \(c.segment)\n"
        p += "Tx: \(c.transactions), Vol: \(drop), Coolers: \(c.coolers), Puertas: \(c.doors)\n"
        p += "3 oraciones: diagnostico, proyeccion si no se actua, accion HOY. Sin emojis. Max 65 palabras."
        return p
    }

    private static func dashPrompt(_ clients: [StoreClient]) -> String {
        let total = clients.count
        let critN = clients.filter { $0.riskPercentage >= 80 }.count
        let medN  = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
        let avgB  = clients.map { $0.uniBoxesSoldM }.reduce(0, +) / Double(max(total, 1))
        let vol   = Int(Double(critN) * avgB * 0.80 + Double(medN) * avgB * 0.40)
        let groups = Dictionary(grouping: clients, by: { $0.territoryD })
        var sorted: [(n: String, a: Double)] = []
        for (key, vals) in groups {
            sorted.append((n: key, a: vals.map { $0.riskPercentage }.reduce(0, +) / Double(vals.count)))
        }
        sorted.sort { $0.a > $1.a }
        let top3 = sorted.prefix(3).map { "\($0.n) (\(String(format:"%.0f",$0.a))%)" }.joined(separator: ", ")
        var p = "Eres agente experto en churn del Canal Tradicional.\n"
        p += "Total: \(total), Criticas: \(critN), Medias: \(medN), Vol riesgo: ~\(vol) cajas\n"
        p += "Top 3 territorios: \(top3)\n"
        p += "2 oraciones ejecutivas: estado global, territorio prioritario. Sin emojis. Max 45 palabras."
        return p
    }

    var fallback: String { buildFallback() }
    var pills: [(label: String, color: Color)] { buildPills() }

    private func buildFallback() -> String {
        switch self {
        case .home(let clients):
            return AgentContext.homeFallback(clients)
        case .storeList(let f, let lvl, _):
            return AgentContext.storeListFallback(f, lvl)
        case .clientDetail(let c):
            let tx = c.transactions == 0 ? "Sin transacciones este periodo." : "\(c.transactions) transacciones registradas."
            return "\(c.riskLevel) con \(Int(c.riskPercentage))% de riesgo. \(tx) Visita prioritaria recomendada."
        case .dashboard(let clients):
            let c = clients.filter { $0.riskPercentage >= 80 }.count
            let m = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            return "\(c) tiendas criticas y \(m) medias de \(clients.count). Revisa territorios prioritarios."
        }
    }

    private static func homeFallback(_ clients: [StoreClient]) -> String {
        let c   = clients.filter { $0.riskPercentage >= 80 }.count
        let m   = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
        let avg = clients.map { $0.uniBoxesSoldM }.reduce(0, +) / Double(max(clients.count, 1))
        let vol = Int(Double(c) * avg * 0.80 + Double(m) * avg * 0.40)
        let groups = Dictionary(grouping: clients, by: { $0.territoryD })
        var best: (n: String, a: Double) = (n: "—", a: 0)
        for (key, vals) in groups {
            let a = vals.map { $0.riskPercentage }.reduce(0, +) / Double(vals.count)
            if a > best.a { best = (n: key, a: a) }
        }
        return "• \(c) criticas, \(m) medias — ~\(vol) cajas en riesgo\n• Territorio prioritario: \(best.n)\n• Visita criticas hoy"
    }

    private static func storeListFallback(_ f: [StoreClient], _ lvl: String) -> String {
        let c = f.filter { $0.riskPercentage >= 80 }.count
        let m = f.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
        return "Vista \(lvl): \(f.count) tiendas — \(c) criticas y \(m) en estado medio."
    }

    private func buildPills() -> [(label: String, color: Color)] {
        switch self {
        case .home(let clients):
            let c = clients.filter { $0.riskPercentage >= 80 }.count
            let m = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            return [("\(c) criticos", AppTheme.wine), ("\(m) medios", AppTheme.softOrange)]
        case .storeList(let f, let lvl, _):
            return [("\(f.count) tiendas", AppTheme.wine), (lvl, AppTheme.softOrange)]
        case .clientDetail(let c):
            let pct = "\(Int(c.riskPercentage))%"
            return [(pct, c.riskColor), (c.riskLevel, c.riskColor)]
        case .dashboard(let clients):
            let c = clients.filter { $0.riskPercentage >= 80 }.count
            return [("\(c) criticos", AppTheme.wine), ("\(clients.count) total", AppTheme.softGreen)]
        }
    }
}

// MARK: - AgentBannerService

struct AgentBannerService {
    static let apiKey   = "AQ.Ab8RN6LjohyNTEIngPwi0VW6SYx6NRK5C6Mv9yWat1-kxyeAlQ"
    static let endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=\(apiKey)"

    static func analyze(context: AgentContext) async throws -> String {
        let body: [String: Any] = [
            "contents": [["parts": [["text": context.prompt]]]],
            "generationConfig": ["temperature": 0.3, "maxOutputTokens": 200]
        ]
        guard let url = URL(string: endpoint) else { throw GeminiError.invalidURL }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw GeminiError.badResponse }
        guard
            let json       = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"] as? [[String: Any]],
            let content    = candidates.first?["content"] as? [String: Any],
            let parts      = content["parts"] as? [[String: Any]],
            let text       = parts.first?["text"] as? String
        else { throw GeminiError.parseError }
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// MARK: - AgentBannerCard

struct AgentBannerCard: View {
    let context: AgentContext
    var onTapReportes: (() -> Void)? = nil

    @State private var message: String? = nil
    @State private var isLoading = false

    private var isHome: Bool { if case .home = context { return true }; return false }

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(alignment: .top, spacing: 14) {
                ZStack {
                    Circle().fill(AppTheme.wine.opacity(0.12)).frame(width: 38, height: 38)
                    if isLoading {
                        ProgressView().tint(AppTheme.wine).scaleEffect(0.75)
                    } else {
                        Image(systemName: "sparkles").font(.system(size: 15, weight: .semibold)).foregroundStyle(AppTheme.wine)
                    }
                }
                VStack(alignment: .leading, spacing: 6) {
                    HStack(spacing: 6) {
                        Text("Agente IA").font(.caption).fontWeight(.bold).foregroundStyle(AppTheme.wine)
                        ForEach(context.pills, id: \.label) { pill in
                            HStack(spacing: 4) {
                                Circle().fill(pill.color).frame(width: 5, height: 5)
                                Text(pill.label).font(.system(size: 10, weight: .semibold)).foregroundStyle(pill.color)
                            }
                            .padding(.horizontal, 6).padding(.vertical, 2)
                            .background(pill.color.opacity(0.08)).clipShape(Capsule())
                        }
                    }
                    if isLoading {
                        VStack(alignment: .leading, spacing: 5) {
                            ForEach(0..<3, id: \.self) { _ in
                                RoundedRectangle(cornerRadius: 3).fill(Color.gray.opacity(0.15))
                                    .frame(height: 9).frame(maxWidth: .infinity)
                            }
                        }
                    } else {
                        BulletTextView(text: message ?? context.fallback)
                    }
                }
                Spacer(minLength: 0)
            }
            if isHome, let action = onTapReportes {
                Button(action: action) {
                    HStack(spacing: 6) {
                        Text("Ver análisis por territorio").font(.system(size: 11, weight: .bold))
                        Image(systemName: "chevron.right").font(.system(size: 10, weight: .bold))
                    }
                    .foregroundStyle(AppTheme.wine)
                    .padding(.horizontal, 12).padding(.vertical, 6)
                    .background(AppTheme.wine.opacity(0.08))
                    .clipShape(Capsule())
                    .overlay(Capsule().strokeBorder(AppTheme.wine.opacity(0.20), lineWidth: 1))
                }
            }
        }
        .padding(14)
        .background(Color.white)
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(AppTheme.wine.opacity(0.15), lineWidth: 1))
        .shadow(color: AppTheme.wine.opacity(0.08), radius: 8, x: 0, y: 3)
        .task {
            guard message == nil else { return }
            isLoading = true
            do { message = try await AgentBannerService.analyze(context: context) }
            catch { message = context.fallback }
            isLoading = false
        }
    }
}

struct BulletTextView: View {
    let text: String
    private var lines: [String] {
        text.components(separatedBy: "\n").map { $0.trimmingCharacters(in: .whitespaces) }.filter { !$0.isEmpty }
    }
    var body: some View {
        if lines.allSatisfy({ $0.hasPrefix("•") }) {
            VStack(alignment: .leading, spacing: 5) {
                ForEach(lines, id: \.self) { line in
                    HStack(alignment: .top, spacing: 6) {
                        Text("•").font(.system(size: 11, weight: .black)).foregroundStyle(AppTheme.wine)
                        Text(line.replacingOccurrences(of: "• ", with: "").replacingOccurrences(of: "•", with: ""))
                            .font(.caption).foregroundStyle(.primary).fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
        } else {
            Text(text).font(.caption).foregroundStyle(.primary).lineSpacing(3).fixedSize(horizontal: false, vertical: true)
        }
    }
}

// MARK: - Store Sort & Filter Enums

enum StoreSort: String, CaseIterable {
    case riskDesc = "Mayor riesgo"; case riskAsc = "Menor riesgo"
    case nameAsc  = "Nombre A-Z";  case nameDesc = "Nombre Z-A"
}

enum RiskLevelFilter: String, CaseIterable, Identifiable {
    case all = "Todos"; case critical = "Crítico"; case medium = "Medio"; case low = "Bajo"
    var id: String { rawValue }
}

// MARK: - Store List Row

struct StoreListRow: View {
    let client: StoreClient
    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().stroke(client.riskColor.opacity(0.15), lineWidth: 4).frame(width: 52, height: 52)
                Circle().trim(from: 0, to: CGFloat(client.riskPercentage / 100))
                    .stroke(client.riskColor, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                    .rotationEffect(.degrees(-90)).frame(width: 52, height: 52)
                Text("\(Int(client.riskPercentage))%").font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(client.riskColor)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(client.storeName).font(.subheadline).fontWeight(.semibold).foregroundStyle(.primary).lineLimit(1)
                HStack(spacing: 4) {
                    Image(systemName: "mappin.circle.fill").font(.system(size: 10)).foregroundStyle(AppTheme.mutedText)
                    Text(client.territoryD).font(.caption).foregroundStyle(AppTheme.mutedText).lineLimit(1)
                }
                HStack(spacing: 4) {
                    Image(systemName: "tag.fill").font(.system(size: 10)).foregroundStyle(AppTheme.mutedText)
                    Text(client.comercialSubchannelD).font(.caption).foregroundStyle(AppTheme.mutedText).lineLimit(1)
                }
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 6) {
                Text(client.riskLevel).font(.system(size: 10, weight: .bold)).foregroundStyle(.white)
                    .padding(.horizontal, 8).padding(.vertical, 3).background(client.riskColor).clipShape(Capsule())
                HStack(spacing: 4) {
                    Image(systemName: "snowflake").font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
                    Text("\(client.coolers)").font(.caption2).foregroundStyle(AppTheme.mutedText)
                    Image(systemName: "cart.fill").font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
                    Text("\(client.transactions)").font(.caption2).foregroundStyle(AppTheme.mutedText)
                }
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 12).background(Color.white).cornerRadius(16)
        .shadow(color: client.riskColor.opacity(0.08), radius: 6, x: 0, y: 2)
    }
}

// MARK: - Dashboard (Home Tab) — merged with StoreListView

// Mini row shown in the home screen for each risk level
struct RiskLevelRow: View {
    let label: String
    let count: Int
    let color: Color
    let onTap: () -> Void

    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 14) {
                ZStack {
                    Circle().fill(color.opacity(0.12)).frame(width: 42, height: 42)
                    Image(systemName: label == "Crítico" ? "exclamationmark.triangle.fill"
                          : label == "Medio" ? "minus.circle.fill" : "checkmark.circle.fill")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(color)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(label).font(.subheadline).fontWeight(.bold).foregroundStyle(.primary)
                    Text(label == "Crítico" ? "Riesgo >= 80%" : label == "Medio" ? "Riesgo 50–79%" : "Riesgo < 50%")
                        .font(.caption2).foregroundStyle(AppTheme.mutedText)
                }
                Spacer()
                Text("\(count)").font(.system(size: 22, weight: .black, design: .rounded)).foregroundStyle(color)
                Image(systemName: "chevron.right").font(.caption).foregroundStyle(color.opacity(0.5))
            }
            .padding(.horizontal, 16).padding(.vertical, 12)
            .background(Color.white)
            .cornerRadius(16)
            .shadow(color: color.opacity(0.10), radius: 6, x: 0, y: 2)
            .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(color.opacity(0.18), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }
}

struct DashboardView: View {
    let clients: [StoreClient]
    @Binding var selectedTab: AppTab

    // Search & filter state
    @State private var searchText    = ""
    @State private var selectedMonth = "Todos"
    @State private var sortBy        = StoreSort.riskDesc
    @State private var levelFilter   = RiskLevelFilter.all
    @State private var searchFocused = false
    @State private var showFilters   = false

    // Sheet state
    @State private var sheetLevel: RiskLevelFilter? = nil
    @State private var showAgentSheet = false
    @State private var bannerVisible  = true

    private var availableMonths: [String] { ["Todos"] + Array(Set(clients.map { $0.calmonth })).sorted() }

    private func monthLabel(_ raw: String) -> String {
        guard raw != "Todos", raw.count == 6,
              let year = Int(raw.prefix(4)), let month = Int(raw.suffix(2)) else { return raw }
        let names = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"]
        guard month >= 1 && month <= 12 else { return raw }
        return "\(names[month-1]) \(String(year).suffix(2))"
    }

    // Counts for current month selection
    private var baseClients: [StoreClient] {
        selectedMonth == "Todos" ? clients : clients.filter { $0.calmonth == selectedMonth }
    }
    private var criticalCount: Int { baseClients.filter { $0.riskPercentage >= 80 }.count }
    private var mediumCount:   Int { baseClients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count }
    private var lowCount:      Int { baseClients.filter { $0.riskPercentage < 50 }.count }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .trailing) {
                AppTheme.appBackground.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 16) {

                        // ── Saludo ──────────────────────────────────────────
                        HeaderView()

                        // ── Barra de búsqueda + mes ─────────────────────────
                        VStack(alignment: .leading, spacing: 10) {
                            // Search bar
                            HStack(spacing: 10) {
                                Image(systemName: "magnifyingglass").foregroundStyle(AppTheme.mutedText)
                                TextField("Buscar tienda, territorio...", text: $searchText)
                                    .font(.subheadline)
                                    .onTapGesture { withAnimation(.spring(response: 0.3)) { searchFocused = true } }
                                if !searchText.isEmpty {
                                    Button { searchText = "" } label: {
                                        Image(systemName: "xmark.circle.fill").foregroundStyle(AppTheme.mutedText)
                                    }
                                }
                                if searchFocused {
                                    Button("Cancelar") {
                                        withAnimation(.spring(response: 0.3)) {
                                            searchFocused = false
                                            searchText = ""
                                            showFilters = false
                                        }
                                    }
                                    .font(.caption).foregroundStyle(AppTheme.wine)
                                }
                            }
                            .padding(.horizontal, 12).padding(.vertical, 10)
                            .background(Color.white).cornerRadius(12)
                            .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                            // Month pills
                            ScrollView(.horizontal, showsIndicators: false) {
                                HStack(spacing: 8) {
                                    ForEach(availableMonths, id: \.self) { month in
                                        Button { withAnimation(.spring(response: 0.25)) { selectedMonth = month } } label: {
                                            Text(monthLabel(month))
                                                .font(.caption).fontWeight(selectedMonth == month ? .bold : .regular)
                                                .foregroundStyle(selectedMonth == month ? .white : AppTheme.wine)
                                                .padding(.horizontal, 14).padding(.vertical, 7)
                                                .background(selectedMonth == month ? AppTheme.wine : AppTheme.wine.opacity(0.08))
                                                .clipShape(Capsule())
                                        }
                                    }
                                }
                            }

                            // Extra filters — only when search is focused
                            if searchFocused {
                                VStack(alignment: .leading, spacing: 10) {
                                    // Sort
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text("Ordenar por").font(.caption).fontWeight(.semibold).foregroundStyle(AppTheme.mutedText)
                                        ScrollView(.horizontal, showsIndicators: false) {
                                            HStack(spacing: 8) {
                                                ForEach(StoreSort.allCases, id: \.self) { s in
                                                    FilterChip(label: s.rawValue, isSelected: sortBy == s, color: AppTheme.wine) { sortBy = s }
                                                }
                                            }
                                        }
                                    }
                                    // Level filter
                                    VStack(alignment: .leading, spacing: 6) {
                                        Text("Nivel de riesgo").font(.caption).fontWeight(.semibold).foregroundStyle(AppTheme.mutedText)
                                        ScrollView(.horizontal, showsIndicators: false) {
                                            HStack(spacing: 8) {
                                                ForEach(RiskLevelFilter.allCases, id: \.self) { f in
                                                    FilterChip(label: f.rawValue, isSelected: levelFilter == f,
                                                               color: f == .critical ? AppTheme.wine : f == .medium ? AppTheme.softOrange : f == .low ? AppTheme.softGreen : AppTheme.wine) { levelFilter = f }
                                                }
                                            }
                                        }
                                    }
                                }
                                .padding(14).background(Color.white).cornerRadius(14)
                                .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                                .transition(.opacity.combined(with: .move(edge: .top)))
                            }
                        }

                        // ── If searching: show filtered list ────────────────
                        if searchFocused || !searchText.isEmpty {
                            let filtered = filteredClients()
                            if filtered.isEmpty {
                                VStack(spacing: 14) {
                                    Image(systemName: "magnifyingglass").font(.system(size: 36)).foregroundStyle(AppTheme.mutedText.opacity(0.4))
                                    Text("Sin resultados").font(.headline).foregroundStyle(AppTheme.mutedText)
                                }
                                .frame(maxWidth: .infinity).padding(.vertical, 40)
                            } else {
                                VStack(spacing: 8) {
                                    ForEach(filtered) { client in
                                        NavigationLink { ClientDetailView(client: client) } label: { StoreListRow(client: client) }
                                            .buttonStyle(.plain)
                                    }
                                }
                            }
                        } else {
                            // ── Normal home content ──────────────────────────

                            // 3 filas de riesgo
                            VStack(spacing: 10) {
                                RiskLevelRow(label: "Crítico", count: criticalCount, color: AppTheme.wine)    { sheetLevel = .critical }
                                RiskLevelRow(label: "Medio",   count: mediumCount,   color: AppTheme.softOrange) { sheetLevel = .medium }
                                RiskLevelRow(label: "Bajo",    count: lowCount,      color: AppTheme.softGreen)  { sheetLevel = .low }
                            }

                            // Donut chart
                            RiskSummaryCard(clients: baseClients)

                            // Agente IA
                            AgentBannerCard(
                                context: .home(clients: clients),
                                onTapReportes: { selectedTab = .reports }
                            )
                            .background(
                                GeometryReader { geo in
                                    Color.clear.onChange(of: geo.frame(in: .global).maxY) { _, maxY in
                                        withAnimation(.easeInOut(duration: 0.25)) { bannerVisible = maxY > 100 }
                                    }
                                }
                            )
                        }
                    }
                    .padding(.horizontal, 16).padding(.top, 18).padding(.bottom, 32)
                }

                // Floating agent button when banner is off-screen
                if !bannerVisible && !(searchFocused || !searchText.isEmpty) {
                    Button { showAgentSheet = true } label: {
                        AgentLogoView()
                            .frame(width: 52, height: 52)
                            .background(Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 14))
                            .shadow(color: AppTheme.wine.opacity(0.25), radius: 10, x: -3, y: 0)
                    }
                    .offset(x: 8)
                    .frame(maxHeight: .infinity, alignment: .center)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                    .zIndex(10)
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showAgentSheet) {
                AgentSheetView(clients: clients)
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
            .sheet(item: $sheetLevel) { level in
                RiskLevelListSheet(clients: baseClients, level: level)
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
            }
        }
    }

    private func filteredClients() -> [StoreClient] {
        var result = baseClients
        if !searchText.isEmpty {
            let q = searchText.lowercased()
            result = result.filter {
                $0.storeName.lowercased().contains(q) ||
                $0.territoryD.lowercased().contains(q) ||
                $0.comercialSubchannelD.lowercased().contains(q)
            }
        }
        switch levelFilter {
        case .critical: result = result.filter { $0.riskPercentage >= 80 }
        case .medium:   result = result.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }
        case .low:      result = result.filter { $0.riskPercentage < 50 }
        case .all:      break
        }
        switch sortBy {
        case .riskDesc: result.sort { $0.riskPercentage > $1.riskPercentage }
        case .riskAsc:  result.sort { $0.riskPercentage < $1.riskPercentage }
        case .nameAsc:  result.sort { $0.storeName < $1.storeName }
        case .nameDesc: result.sort { $0.storeName > $1.storeName }
        }
        return result
    }
}

// Sheet that shows the full list for a given risk level
struct RiskLevelListSheet: View {
    let clients: [StoreClient]
    let level: RiskLevelFilter
    @State private var searchText = ""
    @Environment(\.dismiss) private var dismiss

    private var filtered: [StoreClient] {
        var result: [StoreClient]
        switch level {
        case .critical: result = clients.filter { $0.riskPercentage >= 80 }
        case .medium:   result = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }
        case .low:      result = clients.filter { $0.riskPercentage < 50 }
        case .all:      result = clients
        }
        if !searchText.isEmpty {
            let q = searchText.lowercased()
            result = result.filter { $0.storeName.lowercased().contains(q) || $0.territoryD.lowercased().contains(q) }
        }
        return result.sorted { $0.riskPercentage > $1.riskPercentage }
    }

    private var levelColor: Color {
        switch level {
        case .critical: return AppTheme.wine
        case .medium:   return AppTheme.softOrange
        case .low:      return AppTheme.softGreen
        case .all:      return AppTheme.wine
        }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()
                VStack(spacing: 0) {
                    // Header
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Tiendas \(level.rawValue)")
                                    .font(.title2).fontWeight(.bold)
                                Text("\(filtered.count) tiendas encontradas")
                                    .font(.caption).foregroundStyle(AppTheme.mutedText)
                            }
                            Spacer()
                            Button { dismiss() } label: {
                                Image(systemName: "xmark.circle.fill")
                                    .font(.title2).foregroundStyle(Color.gray.opacity(0.4))
                            }
                        }
                        HStack(spacing: 10) {
                            Image(systemName: "magnifyingglass").foregroundStyle(AppTheme.mutedText)
                            TextField("Buscar...", text: $searchText).font(.subheadline)
                            if !searchText.isEmpty {
                                Button { searchText = "" } label: { Image(systemName: "xmark.circle.fill").foregroundStyle(AppTheme.mutedText) }
                            }
                        }
                        .padding(.horizontal, 12).padding(.vertical, 10).background(Color.white).cornerRadius(12)
                        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                    }
                    .padding(.horizontal, 16).padding(.top, 20).padding(.bottom, 12)

                    List {
                        ForEach(filtered) { client in
                            NavigationLink { ClientDetailView(client: client) } label: { StoreListRow(client: client) }
                                .listRowBackground(Color.clear).listRowSeparator(.hidden)
                                .listRowInsets(EdgeInsets(top: 5, leading: 16, bottom: 5, trailing: 16))
                        }
                    }
                    .listStyle(.plain).scrollIndicators(.hidden)
                }
            }
            .navigationBarHidden(true)
        }
    }
}


// MARK: - Agent Logo

struct AgentLogoView: View {
    var body: some View {
        ZStack {
            Circle()
                .trim(from: 0.15, to: 1.0)
                .stroke(LinearGradient(colors: [AppTheme.wine, AppTheme.wine.opacity(0.4)], startPoint: .top, endPoint: .bottom),
                        style: StrokeStyle(lineWidth: 3.5, lineCap: .round))
                .rotationEffect(.degrees(-30)).frame(width: 28, height: 28).offset(x: -1, y: -2)
            RoundedRectangle(cornerRadius: 2)
                .fill(LinearGradient(colors: [AppTheme.wine, AppTheme.wine.opacity(0.6)], startPoint: .top, endPoint: .bottom))
                .frame(width: 3, height: 10).rotationEffect(.degrees(45)).offset(x: 9, y: 9)
            HStack(alignment: .bottom, spacing: 2.5) {
                ForEach([0.35, 0.55, 0.75, 0.90], id: \.self) { h in
                    RoundedRectangle(cornerRadius: 1)
                        .fill(LinearGradient(colors: [AppTheme.wine, AppTheme.wine.opacity(0.3)], startPoint: .top, endPoint: .bottom))
                        .frame(width: 3, height: 14 * h)
                }
            }
            .offset(x: -2, y: 1)
        }
        .frame(width: 52, height: 52)
    }
}

// MARK: - Agent Sheet

struct AgentSheetView: View {
    let clients: [StoreClient]
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack(spacing: 12) {
                AgentLogoView().frame(width: 44, height: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Churn Hunter Agent").font(.headline).fontWeight(.bold)
                    Text("Análisis autónomo del periodo").font(.caption).foregroundStyle(AppTheme.mutedText)
                }
                Spacer()
            }
            .padding(.horizontal, 20).padding(.top, 20).padding(.bottom, 16)
            Divider()
            ScrollView(showsIndicators: false) {
                AgentBannerCard(context: .home(clients: clients)).padding(16)
            }
        }
        .background(AppTheme.appBackground)
    }
}

// MARK: - Header

struct HeaderView: View {
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Hola, Preventista").font(.title2).fontWeight(.bold)
                Text("Ruta priorizada para hoy").font(.subheadline).foregroundStyle(AppTheme.mutedText)
            }
            Spacer()
        }
    }
}

// MARK: - Risk Summary Card

struct RiskSummaryCard: View {
    let clients: [StoreClient]

    private struct Slice: Identifiable {
        let id = UUID(); let label: String; let value: Double; let color: Color
    }

    private var critical: Int { clients.filter { $0.riskPercentage >= 80 }.count }
    private var medium:   Int { clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count }
    private var low:      Int { clients.filter { $0.riskPercentage < 50 }.count }

    private var slices: [Slice] {[
        Slice(label: "Crítico", value: Double(critical), color: AppTheme.wine),
        Slice(label: "Medio",   value: Double(medium),   color: AppTheme.softOrange),
        Slice(label: "Bajo",    value: Double(low),      color: AppTheme.softGreen),
    ]}

    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Distribución de riesgo").font(.subheadline).foregroundStyle(AppTheme.mutedText)
                Text("$12 MM MXN").font(.system(size: 28, weight: .bold, design: .rounded)).foregroundStyle(AppTheme.wine)
                Text("modelo generado con datos reales").font(.callout)
                ForEach(slices) { slice in
                    HStack(spacing: 6) {
                        Circle().fill(slice.color).frame(width: 8, height: 8)
                        Text(slice.label).font(.caption).foregroundStyle(AppTheme.mutedText)
                        Spacer()
                        Text("\(Int(slice.value))").font(.caption).fontWeight(.bold).foregroundStyle(slice.color)
                    }
                }
            }
            Spacer()
            Chart(slices) { slice in
                SectorMark(angle: .value("Clientes", slice.value), innerRadius: .ratio(0.54), angularInset: 2)
                    .foregroundStyle(slice.color).cornerRadius(4)
            }
            .chartLegend(.hidden)
            .chartBackground { _ in
                VStack(spacing: 0) {
                    Text("\(clients.count)").font(.system(size: 20, weight: .bold, design: .rounded)).foregroundStyle(.primary)
                    Text("tiendas").font(.caption2).foregroundStyle(AppTheme.mutedText)
                }
            }
            .frame(width: 100, height: 100)
        }
        .padding(20).modernCard()
    }
}

// MARK: - Store Risk Card

struct StoreRiskCard: View {
    let client: StoreClient
    var body: some View {
        VStack(spacing: 0) {
            ZStack(alignment: .topTrailing) {
                LiquidGauge(value: client.riskPercentage / 100, color: client.riskColor, size: 110, showLabel: true)
                    .frame(maxWidth: .infinity).padding(.top, 18).padding(.bottom, 10)
                Text(client.riskLevel).font(.system(size: 10, weight: .bold)).foregroundStyle(.white)
                    .padding(.horizontal, 8).padding(.vertical, 4)
                    .background(client.riskColor).clipShape(Capsule()).padding(8)
            }
            VStack(spacing: 5) {
                Text(client.storeName).font(.system(size: 12, weight: .semibold)).foregroundStyle(.primary)
                    .multilineTextAlignment(.center).lineLimit(2).minimumScaleFactor(0.8)
                Text(client.comercialSubchannelD).font(.system(size: 10)).foregroundStyle(AppTheme.mutedText)
                    .multilineTextAlignment(.center).lineLimit(1)
                Divider().padding(.horizontal, 12).padding(.vertical, 4)
                HStack(spacing: 0) {
                    MiniStat(icon: "cart.fill",   value: "\(client.transactions) tx", color: client.riskColor)
                    Divider().frame(height: 22)
                    MiniStat(icon: "shippingbox", value: "\(Int(client.uniBoxesSoldM)) cj", color: client.riskColor)
                    Divider().frame(height: 22)
                    MiniStat(icon: "snowflake",   value: "\(client.coolers)", color: client.riskColor)
                }
            }
            .padding(.horizontal, 10).padding(.bottom, 14)
        }
        .background(AppTheme.cardBackground)
        .cornerRadius(AppTheme.cardCornerRadius)
        .shadow(color: client.riskColor.opacity(0.18), radius: 8, x: 0, y: 3)
        .overlay(RoundedRectangle(cornerRadius: AppTheme.cardCornerRadius).strokeBorder(client.riskColor.opacity(0.20), lineWidth: 1))
    }
}

private struct MiniStat: View {
    let icon: String; let value: String; let color: Color
    var body: some View {
        VStack(spacing: 3) {
            Image(systemName: icon).font(.system(size: 10)).foregroundStyle(color)
            Text(value).font(.system(size: 10, weight: .semibold))
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Liquid Gauge

struct LiquidGauge: View {
    let value: Double; let color: Color; let size: CGFloat
    var showLabel: Bool = true
    @State private var waveOffset: CGFloat = 0
    @State private var appeared = false
    private var fill: CGFloat { appeared ? CGFloat(max(0, min(value, 1))) : 0 }

    var body: some View {
        ZStack {
            Circle().fill(color.opacity(0.08))
            LiquidWaveShape(fillFraction: fill, waveOffset: waveOffset).fill(color.opacity(0.85)).clipShape(Circle())
            LiquidWaveShape(fillFraction: fill, waveOffset: waveOffset + .pi * 0.6).fill(color.opacity(0.28)).clipShape(Circle())
            if showLabel {
                Text("\(Int(value * 100))%")
                    .font(.system(size: size * 0.26, weight: .black, design: .rounded))
                    .foregroundStyle(.white).shadow(color: color.opacity(0.9), radius: 3, x: 0, y: 0)
            }
            Circle().strokeBorder(color.opacity(0.30), lineWidth: 2)
        }
        .frame(width: size, height: size)
        .onAppear {
            withAnimation(.easeOut(duration: 1.0)) { appeared = true }
            withAnimation(.linear(duration: 2.2).repeatForever(autoreverses: false)) { waveOffset = .pi * 2 }
        }
    }
}

struct LiquidWaveShape: Shape {
    var fillFraction: CGFloat; var waveOffset: CGFloat
    var animatableData: AnimatablePair<CGFloat, CGFloat> {
        get { AnimatablePair(fillFraction, waveOffset) }
        set { fillFraction = newValue.first; waveOffset = newValue.second }
    }
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let waveHeight = rect.height * 0.055
        let waterY = rect.height * (1 - fillFraction)
        let steps = Int(rect.width)
        path.move(to: CGPoint(x: 0, y: rect.height))
        path.addLine(to: CGPoint(x: 0, y: waterY))
        for i in 0...steps {
            let x = CGFloat(i)
            let y = waterY + sin((x / rect.width) * .pi * 2 + waveOffset) * waveHeight
            path.addLine(to: CGPoint(x: x, y: y))
        }
        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        path.closeSubpath()
        return path
    }
}

// MARK: - Encuesta State Manager (session-level)
// ── CHANGE 3: New survey system ──────────────────────────────────────────────

class EncuestaStateManager: ObservableObject {
    static let shared = EncuestaStateManager()
    @Published var submittedClientIds: Set<String> = []
    func isSubmitted(_ id: String) -> Bool { submittedClientIds.contains(id) }
    func markSubmitted(_ id: String) { submittedClientIds.insert(id) }
}

// MARK: - Encuesta Banner

struct EncuestaBannerView: View {
    let client: StoreClient
    @ObservedObject private var stateManager = EncuestaStateManager.shared
    @State private var showForm = false

    private var submitted: Bool { stateManager.isSubmitted(client.customerId) }

    var body: some View {
        Group {
            if submitted {
                // Gris y bloqueado
                HStack(spacing: 12) {
                    ZStack {
                        Circle().fill(Color.gray.opacity(0.10)).frame(width: 42, height: 42)
                        Image(systemName: "checkmark.circle.fill").font(.system(size: 20)).foregroundStyle(Color.gray.opacity(0.45))
                    }
                    VStack(alignment: .leading, spacing: 3) {
                        Text("Encuesta enviada").font(.caption).fontWeight(.bold).foregroundStyle(Color.gray.opacity(0.55))
                        Text("Retroalimentación registrada para este periodo").font(.caption2).foregroundStyle(Color.gray.opacity(0.40))
                    }
                    Spacer()
                    Text("Completada")
                        .font(.system(size: 10, weight: .semibold)).foregroundStyle(.white)
                        .padding(.horizontal, 10).padding(.vertical, 5)
                        .background(Color.gray.opacity(0.35)).clipShape(Capsule())
                }
                .padding(16)
                .background(Color.gray.opacity(0.04))
                .cornerRadius(16)
                .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(Color.gray.opacity(0.13), lineWidth: 1))
            } else {
                // Activo y colorido
                Button { showForm = true } label: {
                    HStack(spacing: 12) {
                        ZStack {
                            Circle().fill(AppTheme.wine.opacity(0.12)).frame(width: 42, height: 42)
                            Image(systemName: "chart.bar.doc.horizontal.fill").font(.system(size: 16)).foregroundStyle(AppTheme.wine)
                        }
                        VStack(alignment: .leading, spacing: 3) {
                            HStack(spacing: 6) {
                                Text("Encuesta pendiente").font(.caption).fontWeight(.bold).foregroundStyle(AppTheme.wine)
                                Circle().fill(AppTheme.wine).frame(width: 6, height: 6)
                            }
                            Text("Califica la visita a esta tienda").font(.caption2).foregroundStyle(AppTheme.mutedText)
                        }
                        Spacer()
                        HStack(spacing: 4) {
                            Text("Llenar").font(.system(size: 10, weight: .bold))
                            Image(systemName: "chevron.right").font(.system(size: 9, weight: .bold))
                        }
                        .foregroundStyle(.white).padding(.horizontal, 10).padding(.vertical, 6)
                        .background(AppTheme.wine).clipShape(Capsule())
                    }
                    .padding(16)
                    .background(AppTheme.wine.opacity(0.04))
                    .cornerRadius(16)
                    .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(AppTheme.wine.opacity(0.25), lineWidth: 1.2))
                }
                .buttonStyle(.plain)
                .sheet(isPresented: $showForm) {
                    EncuestaFormSheet(clientName: client.storeName) {
                        showForm = false
                        withAnimation { stateManager.markSubmitted(client.customerId) }
                    }
                    .presentationDetents([.large])
                    .presentationDragIndicator(.visible)
                }
            }
        }
    }
}

// MARK: - Encuesta Form Sheet

struct EncuestaFormSheet: View {
    let clientName: String
    let onSubmit: () -> Void

    @State private var satisfaccion: Int = 8
    @State private var pedidoCompleto: Bool = true
    @State private var preventistaPuntual: Bool = true
    @State private var coolerFuncional: Bool = true
    @State private var recomendariaRepartidor: Bool = true
    @State private var comentario: String = ""
    @Environment(\.dismiss) private var dismiss

    private var satColor: Color {
        satisfaccion >= 9 ? AppTheme.softGreen : satisfaccion >= 7 ? AppTheme.softOrange : AppTheme.wine
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 20) {
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Encuesta de visita").font(.title3).fontWeight(.bold)
                            Text(clientName).font(.subheadline).foregroundStyle(AppTheme.mutedText)
                        }

                        // Satisfacción
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Satisfacción general").font(.caption).fontWeight(.semibold).foregroundStyle(AppTheme.mutedText)
                            HStack(alignment: .firstTextBaseline, spacing: 4) {
                                Text("\(satisfaccion)")
                                    .font(.system(size: 44, weight: .black, design: .rounded))
                                    .foregroundStyle(satColor).animation(.spring(), value: satisfaccion)
                                Text("/ 10").font(.title3).foregroundStyle(AppTheme.mutedText)
                            }
                            Slider(value: Binding(get: { Double(satisfaccion) }, set: { satisfaccion = Int($0) }), in: 1...10, step: 1)
                                .tint(satColor)
                            HStack {
                                Text("Muy malo").font(.caption2).foregroundStyle(AppTheme.mutedText)
                                Spacer()
                                Text("Excelente").font(.caption2).foregroundStyle(AppTheme.mutedText)
                            }
                        }
                        .padding(16).modernCard()

                        // Preguntas sí/no
                        VStack(alignment: .leading, spacing: 14) {
                            Text("Preguntas de visita").font(.caption).fontWeight(.semibold).foregroundStyle(AppTheme.mutedText)
                            EncuestaToggleRow(label: "¿El pedido llegó completo?",    icon: "shippingbox.fill",     value: $pedidoCompleto)
                            Divider()
                            EncuestaToggleRow(label: "¿El preventista fue puntual?",  icon: "clock.fill",            value: $preventistaPuntual)
                            Divider()
                            EncuestaToggleRow(label: "¿El cooler estaba funcional?",  icon: "snowflake",             value: $coolerFuncional)
                            Divider()
                            EncuestaToggleRow(label: "¿Recomendarías al repartidor?", icon: "person.fill.checkmark", value: $recomendariaRepartidor)
                        }
                        .padding(16).modernCard()

                        // Comentario
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Comentario (opcional)").font(.caption).fontWeight(.semibold).foregroundStyle(AppTheme.mutedText)
                            ZStack(alignment: .topLeading) {
                                if comentario.isEmpty {
                                    Text("Escribe algún comentario sobre la visita...")
                                        .font(.subheadline).foregroundStyle(Color.gray.opacity(0.4))
                                        .padding(.horizontal, 14).padding(.vertical, 14)
                                }
                                TextEditor(text: $comentario)
                                    .font(.subheadline).frame(minHeight: 80)
                                    .padding(.horizontal, 10).padding(.vertical, 8)
                                    .opacity(comentario.isEmpty ? 0.8 : 1)
                            }
                            .background(Color.white).cornerRadius(12)
                            .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(Color.gray.opacity(0.15), lineWidth: 1))
                        }

                        Button(action: onSubmit) {
                            HStack(spacing: 8) {
                                Image(systemName: "paperplane.fill").font(.subheadline)
                                Text("Enviar encuesta").font(.subheadline).fontWeight(.bold)
                            }
                            .foregroundStyle(.white).frame(maxWidth: .infinity)
                            .padding(.vertical, 16).background(AppTheme.wine).cornerRadius(14)
                        }
                    }
                    .padding(20).padding(.bottom, 32)
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancelar") { dismiss() }.foregroundStyle(AppTheme.mutedText)
                }
            }
        }
    }
}

private struct EncuestaToggleRow: View {
    let label: String; let icon: String
    @Binding var value: Bool
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: icon).font(.system(size: 13)).foregroundStyle(AppTheme.wine).frame(width: 22)
            Text(label).font(.subheadline)
            Spacer()
            Toggle("", isOn: $value).tint(AppTheme.softGreen).labelsHidden()
        }
    }
}

// MARK: - Client Detail
// ── CHANGE 3: EncuestaBannerView added after AgentBannerCard ────────────────

struct ClientDetailView: View {
    let client: StoreClient
    var body: some View {
        ZStack {
            AppTheme.appBackground.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    ClientHeaderCard(client: client)
                    HStack(spacing: 12) {
                        MetricCard(title: "Coolers",    value: "\(client.coolers)",         icon: "snowflake")
                        MetricCard(title: "Territorio", value: client.territoryD,            icon: "map.fill")
                    }
                    HStack(spacing: 12) {
                        MetricCard(title: "Subcanal",   value: client.comercialSubchannelD,  icon: "tag.fill")
                        MetricCard(title: "Cajas/mes",  value: "\(Int(client.uniBoxesSoldM)) cj", icon: "shippingbox.fill")
                    }
                    HStack(spacing: 12) {
                        MetricCard(title: "Transacciones", value: "\(client.transactions)",  icon: "cart.fill")
                        MetricCard(title: "Puertas",       value: "\(client.doors)",         icon: "door.left.hand.open")
                    }
                    MetricCard(title: "Tamaño cliente", value: client.customerSize, icon: "person.3.fill", isWide: true)

                    AgentBannerCard(context: .clientDetail(client: client))

                    // ── Encuesta banner: activo (colorido) o enviado (gris) ──
                    EncuestaBannerView(client: client)

                    GeminiInsightCard(client: client)

                    VStack(alignment: .leading, spacing: 6) {
                        Text("ID del cliente").font(.caption).foregroundStyle(AppTheme.mutedText)
                        Text(client.customerId).font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(AppTheme.mutedText).lineLimit(2).minimumScaleFactor(0.7)
                    }
                    .padding(14).frame(maxWidth: .infinity, alignment: .leading).modernCard()
                }
                .padding(20).padding(.bottom, 32)
            }
        }
        .navigationTitle(client.storeName)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Client Header Card

struct ClientHeaderCard: View {
    let client: StoreClient
    var body: some View {
        VStack(spacing: 16) {
            HStack {
                LiquidGauge(value: client.riskPercentage / 100, color: client.riskColor, size: 80, showLabel: true)
                Spacer()
                VStack(alignment: .trailing, spacing: 6) {
                    Text("\(Int(client.riskPercentage))%")
                        .font(.system(size: 36, weight: .black, design: .rounded)).foregroundStyle(client.riskColor)
                    Text(client.riskLevel).font(.caption).fontWeight(.bold).foregroundStyle(.white)
                        .padding(.horizontal, 12).padding(.vertical, 6).background(client.riskColor).clipShape(Capsule())
                }
            }
            VStack(alignment: .leading, spacing: 4) {
                Text(client.storeName).font(.title2).fontWeight(.bold)
                Text("Canal Tradicional · Modelo de riesgo de churn").font(.subheadline).foregroundStyle(AppTheme.mutedText)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(20).modernCard()
    }
}

// MARK: - Metric Card

struct MetricCard: View {
    let title: String; let value: String; let icon: String
    var isWide: Bool = false
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(AppTheme.wine.opacity(0.10)).frame(width: 40, height: 40)
                Image(systemName: icon).font(.headline).foregroundStyle(AppTheme.wine)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.caption).foregroundStyle(AppTheme.mutedText)
                Text(value).font(.headline).fontWeight(.bold).lineLimit(1).minimumScaleFactor(0.7)
            }
            Spacer()
        }
        .padding(14).frame(maxWidth: .infinity).modernCard()
    }
}

// MARK: - Gemini Service

struct GeminiService {
    static let apiKey    = "AQ.Ab8RN6LjohyNTEIngPwi0VW6SYx6NRK5C6Mv9yWat1-kxyeAlQ"
    static let endpoint  = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=\(apiKey)"

    static func analyze(client: StoreClient) async throws -> AgentInsight {
        let prompt = """
        Eres un agente experto en análisis de churn para el Canal Tradicional de bebidas en México.
        Analiza los datos de esta tienda y genera una predicción autónoma.
        DATOS: Nombre: \(client.storeName), Territorio: \(client.territoryD), Subcanal: \(client.comercialSubchannelD)
        Tamaño: \(client.customerSize), Riesgo: \(String(format: "%.1f", client.riskPercentage))% (\(client.riskLevel))
        Segmento: \(client.segment), Coolers: \(client.coolers), Puertas: \(client.doors)
        Transacciones: \(client.transactions), Cajas: \(String(format: "%.0f", client.uniBoxesSoldM))
        Responde ÚNICAMENTE con este JSON válido, sin texto adicional:
        {"prediction":"Promotor o Pasivo o Detractor","confidence":número 0-100,"trend":"mejorando o estable o deteriorando","analysis":"2 oraciones máximo","action":"1 acción concreta esta semana","priority":"Alta o Media o Baja"}
        """
        let body: [String: Any] = [
            "contents": [["parts": [["text": prompt]]]],
            "generationConfig": ["temperature": 0.3, "maxOutputTokens": 300]
        ]
        guard let url = URL(string: endpoint) else { throw GeminiError.invalidURL }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw GeminiError.badResponse }
        guard
            let json       = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"] as? [[String: Any]],
            let content    = candidates.first?["content"] as? [String: Any],
            let parts      = content["parts"] as? [[String: Any]],
            let text       = parts.first?["text"] as? String
        else { throw GeminiError.parseError }
        let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "```json", with: "").replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        guard let jsonData = clean.data(using: .utf8), let parsed = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
        else { throw GeminiError.parseError }
        return AgentInsight(
            prediction: parsed["prediction"] as? String ?? "—",
            confidence: parsed["confidence"] as? Int    ?? 0,
            trend:      parsed["trend"]      as? String ?? "estable",
            analysis:   parsed["analysis"]   as? String ?? "Sin análisis disponible.",
            action:     parsed["action"]     as? String ?? "Realizar visita de seguimiento.",
            priority:   parsed["priority"]   as? String ?? "Media"
        )
    }
}

enum GeminiError: Error { case invalidURL, badResponse, parseError }

struct AgentInsight {
    let prediction: String; let confidence: Int; let trend: String
    let analysis: String; let action: String; let priority: String
    var predictionColor: Color {
        switch prediction { case "Detractor": return AppTheme.wine; case "Pasivo": return AppTheme.softOrange; default: return AppTheme.softGreen }
    }
    var trendIcon: String {
        switch trend { case "deteriorando": return "arrow.down.right.circle.fill"; case "mejorando": return "arrow.up.right.circle.fill"; default: return "minus.circle.fill" }
    }
    var trendColor: Color {
        switch trend { case "deteriorando": return AppTheme.wine; case "mejorando": return AppTheme.softGreen; default: return AppTheme.softOrange }
    }
}

// MARK: - Gemini Insight Card

struct GeminiInsightCard: View {
    let client: StoreClient
    @State private var insight: AgentInsight? = nil
    @State private var isLoading = false
    @State private var errorMsg: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(AppTheme.wine.opacity(0.12)).frame(width: 44, height: 44)
                    if isLoading { ProgressView().tint(AppTheme.wine).scaleEffect(0.8) }
                    else { Image(systemName: "sparkles").font(.title3).foregroundStyle(AppTheme.wine) }
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Churn Hunter Agent").font(.headline).fontWeight(.bold)
                    Text(isLoading ? "Analizando con IA..." : "Análisis autónomo generado").font(.caption).foregroundStyle(AppTheme.mutedText)
                }
                Spacer()
                if let ins = insight {
                    Text("\(ins.confidence)% conf.").font(.system(size: 10, weight: .bold)).foregroundStyle(.white)
                        .padding(.horizontal, 8).padding(.vertical, 4).background(ins.predictionColor).clipShape(Capsule())
                }
            }
            if isLoading {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(0..<3, id: \.self) { i in
                        RoundedRectangle(cornerRadius: 4).fill(Color.gray.opacity(0.12)).frame(height: 12)
                            .frame(maxWidth: i == 2 ? .infinity * 0.6 : .infinity)
                    }
                }
            } else if let err = errorMsg {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle").foregroundStyle(AppTheme.softOrange)
                    Text(err).font(.caption).foregroundStyle(AppTheme.mutedText)
                }
            } else if let ins = insight {
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Predicción próximo mes").font(.caption2).foregroundStyle(AppTheme.mutedText)
                        Text(ins.prediction).font(.system(size: 18, weight: .black, design: .rounded)).foregroundStyle(ins.predictionColor)
                    }
                    Spacer()
                    HStack(spacing: 4) {
                        Image(systemName: ins.trendIcon).foregroundStyle(ins.trendColor)
                        Text(ins.trend.capitalized).font(.caption).fontWeight(.semibold).foregroundStyle(ins.trendColor)
                    }
                    .padding(.horizontal, 10).padding(.vertical, 6).background(ins.trendColor.opacity(0.10)).cornerRadius(10)
                }
                Divider()
                Text(ins.analysis).font(.subheadline).lineSpacing(4).fixedSize(horizontal: false, vertical: true)
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "checkmark.seal.fill").foregroundStyle(AppTheme.wine).font(.subheadline)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Acción recomendada").font(.caption2).foregroundStyle(AppTheme.mutedText)
                        Text(ins.action).font(.caption).fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(12).background(AppTheme.wine.opacity(0.05)).cornerRadius(10)
                HStack(spacing: 6) {
                    Circle().fill(ins.predictionColor).frame(width: 7, height: 7)
                    Text("Prioridad \(ins.priority)").font(.caption2).fontWeight(.semibold).foregroundStyle(ins.predictionColor)
                }
            }
        }
        .padding(20).background(Color.white).cornerRadius(18)
        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(AppTheme.wine.opacity(0.20), lineWidth: 1.2))
        .shadow(color: AppTheme.wine.opacity(0.14), radius: 12, x: 0, y: 5)
        .task {
            guard insight == nil else { return }
            isLoading = true
            do { insight = try await GeminiService.analyze(client: client) }
            catch { errorMsg = "No se pudo conectar con el agente. Verifica tu API key." }
            isLoading = false
        }
    }
}

// MARK: - Filter & Summary Chips

struct FilterChip: View {
    let label: String; let isSelected: Bool; let color: Color; let action: () -> Void
    var body: some View {
        Button(action: action) {
            Text(label).font(.caption).fontWeight(isSelected ? .bold : .regular)
                .foregroundStyle(isSelected ? .white : color)
                .padding(.horizontal, 14).padding(.vertical, 7)
                .background(isSelected ? color : color.opacity(0.10)).clipShape(Capsule())
        }
    }
}

struct SummaryChip: View {
    let count: Int; let label: String; let color: Color
    var body: some View {
        HStack(spacing: 5) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text("\(count) \(label)").font(.caption2).fontWeight(.semibold).foregroundStyle(color)
        }
        .padding(.horizontal, 10).padding(.vertical, 5).background(color.opacity(0.10)).clipShape(Capsule())
    }
}

// MARK: - Executive Dashboard View
// ── CHANGE 4: "Tiendas Críticas" block removed ──────────────────────────────

struct ExecutiveDashboardView: View {
    let clients: [StoreClient]

    private var total:        Int    { clients.count }
    private var critical:     Int    { clients.filter { $0.riskPercentage >= 80 }.count }
    private var medium:       Int    { clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count }
    private var avgRisk:      Double { clients.isEmpty ? 0 : clients.map(\.riskPercentage).reduce(0,+) / Double(total) }
    private var totalBoxes:   Int    { Int(clients.map(\.uniBoxesSoldM).reduce(0,+)) }
    private var totalTx:      Int    { clients.map(\.transactions).reduce(0,+) }
    private var totalCoolers: Int    { clients.map(\.coolers).reduce(0,+) }

    private var riskBuckets: [DashBucket] {
        (0..<10).map { i in
            let lo = Double(i*10), hi = Double((i+1)*10)
            let n = clients.filter { $0.riskPercentage >= lo && (i == 9 ? $0.riskPercentage <= hi : $0.riskPercentage < hi) }.count
            let color: Color = i >= 8 ? AppTheme.wine : i >= 5 ? AppTheme.softOrange : AppTheme.softGreen
            return DashBucket(label: "\(i*10)", value: n, color: color)
        }
    }

    private var topTerritories: [TerritoryData] {
        Dictionary(grouping: clients, by: \.territoryD)
            .map { key, vals in TerritoryData(name: key, avgRisk: vals.map(\.riskPercentage).reduce(0,+)/Double(vals.count), count: vals.count) }
            .sorted { $0.avgRisk > $1.avgRisk }.prefix(5).map { $0 }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        DashHeader().padding(.horizontal, 20).padding(.top, 8)
                        VStack(alignment: .leading, spacing: 20) {
                            HStack(spacing: 12) {
                                ArcKpiCard(title: "Riesgo Prom.", value: "\(Int(avgRisk))%", subtitle: "de 100%", pct: avgRisk / 100,
                                           icon: "exclamationmark.triangle.fill",
                                           color: avgRisk >= 80 ? AppTheme.wine : avgRisk >= 50 ? AppTheme.softOrange : AppTheme.softGreen)
                                ArcKpiCard(title: "Coolers", value: "\(totalCoolers)", subtitle: "\(total) tiendas",
                                           pct: min(Double(totalCoolers)/Double(max(total*3,1)), 1.0),
                                           icon: "snowflake", color: Color(red: 0.20, green: 0.45, blue: 0.85))
                            }
                            HStack(spacing: 12) {
                                MiniKpiCard(title: "Cajas", value: "\(totalBoxes)", icon: "shippingbox.fill", color: AppTheme.softGreen,
                                            sparkValues: riskBuckets.prefix(5).map { Double($0.value) })
                                MiniKpiCard(title: "Transacciones", value: "\(totalTx)", icon: "cart.fill", color: AppTheme.softOrange,
                                            sparkValues: riskBuckets.suffix(5).map { Double($0.value) })
                            }

                            // Distribución de riesgo chart
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Distribución de Riesgo").font(.subheadline).fontWeight(.bold)
                                        Text("Clientes por rango (%)").font(.caption2).foregroundStyle(AppTheme.mutedText)
                                    }
                                    Spacer()
                                    HStack(spacing: 6) {
                                        LegendPill(color: AppTheme.softGreen, label: "Bajo")
                                        LegendPill(color: AppTheme.softOrange, label: "Medio")
                                        LegendPill(color: AppTheme.wine, label: "Crítico")
                                    }
                                }
                                Chart {
                                    ForEach(riskBuckets) { b in
                                        AreaMark(x: .value("Rango", b.label), y: .value("Clientes", b.value))
                                            .foregroundStyle(LinearGradient(colors: [b.color.opacity(0.45), b.color.opacity(0.05)], startPoint: .top, endPoint: .bottom))
                                            .interpolationMethod(.catmullRom)
                                        LineMark(x: .value("Rango", b.label), y: .value("Clientes", b.value))
                                            .foregroundStyle(b.color).lineStyle(StrokeStyle(lineWidth: 2.5)).interpolationMethod(.catmullRom)
                                        PointMark(x: .value("Rango", b.label), y: .value("Clientes", b.value))
                                            .foregroundStyle(b.color).symbolSize(30)
                                    }
                                }
                                .chartXAxis {
                                    AxisMarks(values: .automatic(desiredCount: 5)) { val in
                                        AxisValueLabel { if let s = val.as(String.self) { Text("\(s)%").font(.system(size: 9)).foregroundStyle(AppTheme.mutedText) } }
                                    }
                                }
                                .chartYAxis {
                                    AxisMarks(position: .leading, values: .automatic(desiredCount: 4)) { _ in
                                        AxisGridLine(stroke: StrokeStyle(lineWidth: 0.5, dash: [4])).foregroundStyle(Color.gray.opacity(0.2))
                                        AxisValueLabel().font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
                                    }
                                }
                                .frame(height: 170)
                            }
                            .padding(16).modernCard()

                            // Territorios
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    Text("Territorios en Riesgo").font(.subheadline).fontWeight(.bold)
                                    Spacer()
                                    Text("Top 5").font(.caption2).fontWeight(.semibold).foregroundStyle(AppTheme.wine)
                                        .padding(.horizontal, 8).padding(.vertical, 3).background(AppTheme.wine.opacity(0.10)).clipShape(Capsule())
                                }
                                ForEach(topTerritories) { t in TerritoryProgressRow(data: t) }
                            }
                            .padding(16).modernCard()

                            // ── CHANGE 4: Tiendas Críticas block REMOVED ────
                            // AgentBanner al final del dashboard
                            AgentBannerCard(context: .dashboard(clients: clients))
                        }
                        .padding(.horizontal, 20).padding(.top, 8).padding(.bottom, 32)
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}

// MARK: - Dashboard Data Models

private struct DashBucket: Identifiable { let id = UUID(); let label: String; let value: Int; let color: Color }
private struct TerritoryData: Identifiable { let id = UUID(); let name: String; let avgRisk: Double; let count: Int }

private struct DashHeader: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Dashboard").font(.title2).fontWeight(.bold).foregroundStyle(AppTheme.wine)
            Text("Análisis de riesgo · Canal Tradicional").font(.caption).foregroundStyle(AppTheme.mutedText)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

private struct ArcKpiCard: View {
    let title: String; let value: String; let subtitle: String
    let pct: Double; let icon: String; let color: Color
    @State private var appeared = false
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(title).font(.caption).foregroundStyle(AppTheme.mutedText)
                Spacer()
                Image(systemName: icon).font(.caption).foregroundStyle(color)
            }
            ZStack {
                Circle().trim(from: 0.15, to: 0.85).stroke(color.opacity(0.12), style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(126)).frame(width: 88, height: 88)
                Circle().trim(from: 0.15, to: 0.15 + (appeared ? 0.70 * CGFloat(pct) : 0))
                    .stroke(color, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(126)).frame(width: 88, height: 88)
                    .animation(.easeOut(duration: 1.1), value: appeared)
                VStack(spacing: 0) {
                    Text(value).font(.system(size: 20, weight: .black, design: .rounded)).foregroundStyle(color)
                    Text(subtitle).font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
                }
            }
            .frame(maxWidth: .infinity, alignment: .center)
        }
        .padding(14).frame(maxWidth: .infinity).background(Color.white).cornerRadius(20)
        .shadow(color: color.opacity(0.12), radius: 8, x: 0, y: 3)
        .onAppear { appeared = true }
    }
}

private struct MiniKpiCard: View {
    let title: String; let value: String; let icon: String; let color: Color; let sparkValues: [Double]
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: icon).font(.caption).foregroundStyle(color)
                Text(title).font(.caption).foregroundStyle(AppTheme.mutedText)
            }
            if sparkValues.count > 1 {
                let maxV = sparkValues.max() ?? 1
                Chart {
                    ForEach(Array(sparkValues.enumerated()), id: \.offset) { i, v in
                        AreaMark(x: .value("i", i), y: .value("v", v))
                            .foregroundStyle(LinearGradient(colors: [color.opacity(0.35), color.opacity(0.05)], startPoint: .top, endPoint: .bottom))
                            .interpolationMethod(.catmullRom)
                        LineMark(x: .value("i", i), y: .value("v", v))
                            .foregroundStyle(color).lineStyle(StrokeStyle(lineWidth: 2)).interpolationMethod(.catmullRom)
                    }
                }
                .chartXAxis(.hidden).chartYAxis(.hidden).chartYScale(domain: 0...(maxV * 1.2)).frame(height: 44)
            }
            Text(value).font(.system(size: 18, weight: .black, design: .rounded)).foregroundStyle(color)
        }
        .padding(14).frame(maxWidth: .infinity, alignment: .leading).background(Color.white).cornerRadius(20)
        .shadow(color: color.opacity(0.10), radius: 8, x: 0, y: 3)
    }
}

private struct LegendPill: View {
    let color: Color; let label: String
    var body: some View {
        HStack(spacing: 3) { Circle().fill(color).frame(width: 6, height: 6); Text(label).font(.system(size: 9)).foregroundStyle(AppTheme.mutedText) }
    }
}

private struct TerritoryProgressRow: View {
    let data: TerritoryData
    private var barColor: Color { data.avgRisk >= 80 ? AppTheme.wine : data.avgRisk >= 50 ? AppTheme.softOrange : AppTheme.softGreen }
    @State private var appeared = false
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text(data.name).font(.caption).fontWeight(.semibold).lineLimit(1)
                Spacer()
                Text("\(Int(data.avgRisk))%").font(.caption).fontWeight(.bold).foregroundStyle(barColor)
                Text("· \(data.count) tiendas").font(.caption2).foregroundStyle(AppTheme.mutedText)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(barColor.opacity(0.10)).frame(height: 7)
                    Capsule()
                        .fill(LinearGradient(colors: [barColor.opacity(0.7), barColor], startPoint: .leading, endPoint: .trailing))
                        .frame(width: geo.size.width * CGFloat(appeared ? data.avgRisk / 100 : 0), height: 7)
                        .animation(.easeOut(duration: 0.9), value: appeared)
                }
            }
            .frame(height: 7)
        }
        .onAppear { appeared = true }
    }
}

// MARK: - Reportes View

struct TerritoryGroup: Identifiable {
    let id = UUID(); let name: String; let stores: [StoreClient]
    let avgRisk: Double; let criticalCount: Int; let mediumCount: Int
    var dominantColor: Color { avgRisk >= 80 ? AppTheme.wine : avgRisk >= 60 ? AppTheme.softOrange : AppTheme.softGreen }
}

struct ReportesView: View {
    let clients: [StoreClient]
    @State private var territorySummaries: [String: String] = [:]
    @State private var loadingTerritories: Set<String> = []

    private var month: String { clients.first?.calmonth ?? "—" }
    private var atRiskClients: [StoreClient] { clients.filter { $0.riskPercentage >= 50 } }

    private var territoryGroups: [TerritoryGroup] {
        let grouped = Dictionary(grouping: atRiskClients, by: { $0.territoryD })
        var result: [TerritoryGroup] = []
        for (key, vals) in grouped {
            let sortedStores = vals.sorted { $0.riskPercentage > $1.riskPercentage }
            let avg  = vals.map { $0.riskPercentage }.reduce(0, +) / Double(vals.count)
            let crit = vals.filter { $0.riskPercentage >= 80 }.count
            let med  = vals.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            result.append(TerritoryGroup(name: key, stores: sortedStores,
                avgRisk: avg, criticalCount: crit, mediumCount: med))
        }
        return result.sorted { $0.avgRisk > $1.avgRisk }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 20) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Reportes").font(.title2).fontWeight(.bold)
                            Text("Detractores por territorio · Periodo \(month)").font(.caption).foregroundStyle(AppTheme.mutedText)
                        }
                        GlobalRiskBadgeRow(clients: clients)
                        ForEach(territoryGroups) { group in
                            NavigationLink { TerritoryDetailView(group: group, summary: territorySummaries[group.name]) } label: {
                                TerritoryReportCard(group: group, summary: territorySummaries[group.name], isLoading: loadingTerritories.contains(group.name))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal, 16).padding(.top, 18).padding(.bottom, 32)
                }
            }
            .navigationBarHidden(true)
            .task { await generateAllSummariesIfNeeded() }
        }
    }

    private func generateAllSummariesIfNeeded() async {
        await withTaskGroup(of: Void.self) { group in
            for tg in territoryGroups {
                guard territorySummaries[tg.name] == nil else { continue }
                group.addTask { await generateTerritorySummary(tg) }
            }
        }
    }

    private func generateTerritorySummary(_ tg: TerritoryGroup) async {
        loadingTerritories.insert(tg.name)
        let storeLines = tg.stores.prefix(8).map { "  \($0.storeName) – \(String(format:"%.0f",$0.riskPercentage))% riesgo, \($0.transactions) tx, \(Int($0.uniBoxesSoldM)) cajas" }.joined(separator: "\n")
        let prompt = """
        Eres un agente experto en churn del Canal Tradicional de bebidas en México.
        TERRITORIO: \(tg.name), Tiendas en riesgo: \(tg.stores.count) (\(tg.criticalCount) críticas, \(tg.mediumCount) medias)
        Riesgo promedio: \(String(format:"%.1f",tg.avgRisk))%
        \(storeLines)
        Escribe exactamente 2 oraciones: 1. Estado del territorio. 2. Acción prioritaria concreta.
        Sin emojis. Sin saludos. Máximo 50 palabras. Solo texto plano.
        """
        do { territorySummaries[tg.name] = try await ReportService.generate(prompt: prompt) }
        catch { territorySummaries[tg.name] = "\(tg.criticalCount) tiendas críticas y \(tg.mediumCount) en estado medio. Visita prioritaria esta semana." }
        loadingTerritories.remove(tg.name)
    }
}

private struct GlobalRiskBadgeRow: View {
    let clients: [StoreClient]
    private var critical: Int { clients.filter { $0.riskPercentage >= 80 }.count }
    private var medium:   Int { clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count }
    private var avgRisk:  Double { clients.map(\.riskPercentage).reduce(0,+) / Double(max(clients.count,1)) }
    private var avgBoxes: Double { clients.map(\.uniBoxesSoldM).reduce(0,+) / Double(max(clients.count,1)) }
    private var volRiesgo: Int { Int(Double(critical)*avgBoxes*0.80 + Double(medium)*avgBoxes*0.40) }
    var body: some View {
        HStack(spacing: 10) {
            GlobalBadge(value: "\(critical)",     label: "Críticas",    color: AppTheme.wine)
            GlobalBadge(value: "\(medium)",       label: "Medias",      color: AppTheme.softOrange)
            GlobalBadge(value: "~\(volRiesgo)",   label: "Cajas riesgo",color: AppTheme.softOrange)
            GlobalBadge(value: "\(Int(avgRisk))%",label: "Riesgo prom", color: AppTheme.wine)
        }
    }
}

private struct GlobalBadge: View {
    let value: String; let label: String; let color: Color
    var body: some View {
        VStack(spacing: 2) {
            Text(value).font(.system(size: 14, weight: .black, design: .rounded)).foregroundStyle(color)
            Text(label).font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
        }
        .frame(maxWidth: .infinity).padding(.vertical, 10).background(color.opacity(0.07)).cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(color.opacity(0.15), lineWidth: 1))
    }
}

struct TerritoryReportCard: View {
    let group: TerritoryGroup; let summary: String?; let isLoading: Bool
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 12) {
                ZStack {
                    Circle().fill(group.dominantColor.opacity(0.12)).frame(width: 44, height: 44)
                    Image(systemName: "mappin.and.ellipse").font(.system(size: 16, weight: .semibold)).foregroundStyle(group.dominantColor)
                }
                VStack(alignment: .leading, spacing: 3) {
                    Text(group.name).font(.subheadline).fontWeight(.bold).foregroundStyle(.primary)
                    HStack(spacing: 6) {
                        RiskBadge(count: group.criticalCount, label: "Críticas", color: AppTheme.wine)
                        RiskBadge(count: group.mediumCount,   label: "Medias",   color: AppTheme.softOrange)
                    }
                }
                Spacer()
                ZStack {
                    Circle().trim(from: 0, to: 1).stroke(group.dominantColor.opacity(0.10), lineWidth: 5)
                    Circle().trim(from: 0, to: CGFloat(group.avgRisk / 100))
                        .stroke(group.dominantColor, style: StrokeStyle(lineWidth: 5, lineCap: .round)).rotationEffect(.degrees(-90))
                    Text("\(Int(group.avgRisk))%").font(.system(size: 11, weight: .black, design: .rounded)).foregroundStyle(group.dominantColor)
                }
                .frame(width: 44, height: 44)
                Image(systemName: "chevron.right").font(.caption2).foregroundStyle(AppTheme.mutedText)
            }
            Divider()
            if isLoading {
                HStack(spacing: 8) {
                    ProgressView().scaleEffect(0.7).tint(group.dominantColor)
                    VStack(alignment: .leading, spacing: 5) {
                        RoundedRectangle(cornerRadius: 3).fill(Color.gray.opacity(0.12)).frame(height: 9).frame(maxWidth: .infinity)
                        RoundedRectangle(cornerRadius: 3).fill(Color.gray.opacity(0.12)).frame(height: 9).frame(maxWidth: 200)
                    }
                }
            } else if let text = summary {
                Text(text).font(.caption).foregroundStyle(.secondary).lineSpacing(3).fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16).background(Color.white).cornerRadius(18)
        .shadow(color: group.dominantColor.opacity(0.10), radius: 8, x: 0, y: 3)
        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(group.dominantColor.opacity(0.18), lineWidth: 1))
    }
}

private struct RiskBadge: View {
    let count: Int; let label: String; let color: Color
    var body: some View {
        HStack(spacing: 3) {
            Circle().fill(color).frame(width: 5, height: 5)
            Text("\(count) \(label)").font(.system(size: 10, weight: .semibold)).foregroundStyle(color)
        }
        .padding(.horizontal, 7).padding(.vertical, 3).background(color.opacity(0.08)).clipShape(Capsule())
    }
}

struct TerritoryDetailView: View {
    let group: TerritoryGroup; let summary: String?
    var body: some View {
        ZStack {
            AppTheme.appBackground.ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack(spacing: 10) {
                            ZStack {
                                Circle().fill(group.dominantColor.opacity(0.12)).frame(width: 40, height: 40)
                                Image(systemName: "sparkles").font(.system(size: 14)).foregroundStyle(group.dominantColor)
                            }
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Análisis IA — \(group.name)").font(.caption).fontWeight(.bold).foregroundStyle(group.dominantColor)
                                Text("\(group.stores.count) tiendas en riesgo").font(.caption2).foregroundStyle(AppTheme.mutedText)
                            }
                        }
                        if let text = summary { Text(text).font(.subheadline).lineSpacing(4).fixedSize(horizontal: false, vertical: true) }
                        HStack(spacing: 10) {
                            RiskBadge(count: group.criticalCount, label: "Críticas", color: AppTheme.wine)
                            RiskBadge(count: group.mediumCount,   label: "Medias",   color: AppTheme.softOrange)
                            Spacer()
                            Text("Prom \(Int(group.avgRisk))%").font(.caption).fontWeight(.bold).foregroundStyle(group.dominantColor)
                        }
                    }
                    .padding(16).background(Color.white).cornerRadius(18)
                    .shadow(color: group.dominantColor.opacity(0.10), radius: 8, x: 0, y: 3)
                    .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(group.dominantColor.opacity(0.18), lineWidth: 1))

                    Text("Tiendas en riesgo").font(.subheadline).fontWeight(.bold).padding(.top, 4)
                    ForEach(group.stores) { client in
                        NavigationLink { ClientDetailView(client: client) } label: { TerritoryStoreRow(client: client) }.buttonStyle(.plain)
                    }
                }
                .padding(.horizontal, 16).padding(.top, 16).padding(.bottom, 32)
            }
        }
        .navigationTitle(group.name).navigationBarTitleDisplayMode(.inline)
    }
}

private struct TerritoryStoreRow: View {
    let client: StoreClient
    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().stroke(client.riskColor.opacity(0.15), lineWidth: 4).frame(width: 48, height: 48)
                Circle().trim(from: 0, to: CGFloat(client.riskPercentage / 100))
                    .stroke(client.riskColor, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                    .rotationEffect(.degrees(-90)).frame(width: 48, height: 48)
                Text("\(Int(client.riskPercentage))%").font(.system(size: 10, weight: .black, design: .rounded)).foregroundStyle(client.riskColor)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(client.storeName).font(.subheadline).fontWeight(.semibold).lineLimit(1).foregroundStyle(.primary)
                Text(client.comercialSubchannelD).font(.caption).foregroundStyle(AppTheme.mutedText).lineLimit(1)
                HStack(spacing: 8) {
                    Label("\(client.transactions) tx", systemImage: "cart.fill")
                    Label("\(Int(client.uniBoxesSoldM)) cj", systemImage: "shippingbox")
                    Label("\(client.coolers)", systemImage: "snowflake")
                }
                .font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 6) {
                Text(client.riskLevel).font(.system(size: 10, weight: .bold)).foregroundStyle(.white)
                    .padding(.horizontal, 8).padding(.vertical, 3).background(client.riskColor).clipShape(Capsule())
                Image(systemName: "chevron.right").font(.caption2).foregroundStyle(AppTheme.mutedText)
            }
        }
        .padding(.horizontal, 14).padding(.vertical, 12).background(Color.white).cornerRadius(16)
        .shadow(color: client.riskColor.opacity(0.08), radius: 6, x: 0, y: 2)
        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(client.riskColor.opacity(0.12), lineWidth: 1))
    }
}

// MARK: - Report Service

struct ReportService {
    static let apiKey   = "AQ.Ab8RN6LjohyNTEIngPwi0VW6SYx6NRK5C6Mv9yWat1-kxyeAlQ"
    static let endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=\(apiKey)"
    static func generate(prompt: String) async throws -> String {
        let body: [String: Any] = ["contents": [["parts": [["text": prompt]]]], "generationConfig": ["temperature": 0.4, "maxOutputTokens": 400]]
        guard let url = URL(string: endpoint) else { throw GeminiError.invalidURL }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"; req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)
        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw GeminiError.badResponse }
        guard
            let json       = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"] as? [[String: Any]],
            let content    = candidates.first?["content"] as? [String: Any],
            let parts      = content["parts"] as? [[String: Any]],
            let text       = parts.first?["text"] as? String
        else { throw GeminiError.parseError }
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

#Preview { MainTabView() }
