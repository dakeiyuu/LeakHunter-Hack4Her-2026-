import SwiftUI
import Charts

enum AppTheme {
    static let wine = Color(red: 0.65, green: 0.05, blue: 0.15)
    static let appBackground = Color(red: 0.96, green: 0.96, blue: 0.98)
    static let cardBackground = Color.white
    static let softOrange = Color(red: 0.95, green: 0.50, blue: 0.10)
    static let softGreen = Color(red: 0.13, green: 0.65, blue: 0.36)
    static let mutedText = Color.gray
    static let cardCornerRadius: CGFloat = 20
}

extension View {
    func modernCard() -> some View {
        self
            .background(AppTheme.cardBackground)
            .cornerRadius(AppTheme.cardCornerRadius)
            .shadow(color: .black.opacity(0.07), radius: 10, x: 0, y: 4)
    }
}

// MARK: - Store Name Generator

enum StoreNameGenerator {
    private static let names = [
        "Abarrotes Juan", "Tienda Los 3 Hermanos", "Mini Super Lupita",
        "Abarrotes El Güero", "Tienda Doña Chayo", "El Recreo de Martínez",
        "Abarrotes La Esquina", "Super Toño", "Tienda El Farolito",
        "Abarrotes Don Memo", "La Tiendita de Rosita", "El Rincón de Pepe",
        "Abarrotes La Paloma", "Tienda Los Compadres", "Mini Súper El Refugio",
        "Abarrotes Hernández", "La Bodega de Carmen", "Tienda El Oasis",
        "Abarrotes El Progreso", "Super Don Lupe", "Tienda La Esperanza",
        "Abarrotes El Nido", "Minisuper Los Primos", "Tienda Don Beto",
        "La Tiendita del Barrio", "Abarrotes La Fe", "Super Ramírez",
        "Tienda El Manantial", "Abarrotes Los Reyes", "El Changarro de Güicho",
        "Tienda Doña Meche", "Abarrotes El Paraíso", "Super La Colonia",
        "Tienda Los Amigos", "Abarrotes El Trebol", "Mini Súper Familia Cruz",
        "La Tiendita de Nachito", "Abarrotes Villa Norte", "Tienda El Pino",
        "Super Don Chico", "Abarrotes La Unión", "Tienda Señora Elvira",
        "El Changarro de Lalo", "Abarrotes El Roble", "Tienda Los Sánchez",
        "Mini Súper El Sauce", "Abarrotes Don Polo", "Tienda La Herradura",
        "Super Los Comales", "Abarrotes El Girasol"
    ]

    static func name(for customerId: String) -> String {
        // Derivar un índice estable a partir del customerId
        let hash = customerId.unicodeScalars.reduce(0) { $0 &+ Int($1.value) }
        return names[abs(hash) % names.count]
    }
}

// MARK: - Model

struct StoreClient: Identifiable, Codable, Hashable {
    let id: String
    let name: String
    let customerId: String
    let calmonth: String
    let territoryD: String
    let comercialSubchannelD: String
    let customerSize: String
    let coolers: Int
    let doors: Int
    let transactions: Int
    let uniBoxesSoldM: Double
    let riskPercentage: Double
    let riskLevel: String
    let segment: String

    // Nombre inventado de la tienda, estable por customerId
    var storeName: String {
        StoreNameGenerator.name(for: customerId)
    }

    var riskColor: Color {
        if riskPercentage >= 80 { return AppTheme.wine }
        if riskPercentage >= 50 { return AppTheme.softOrange }
        return AppTheme.softGreen
    }

    var isCritical: Bool { riskPercentage >= 80 }

    var insight: String {
        """
        Cliente \(segment). Riesgo de churn: \(Int(riskPercentage))%.
        Territorio: \(territoryD).
        Subcanal: \(comercialSubchannelD).
        Tamaño: \(customerSize).
        Coolers: \(coolers), puertas: \(doors), transacciones: \(transactions).
        Cajas vendidas: \(Int(uniBoxesSoldM)).
        Recomendación: priorizar visita comercial, validar inventario frío y generar pedido de recuperación.
        """
    }
}

// MARK: - Data Loader

struct ClientDataLoader {
    static func loadClients() -> [StoreClient] {
        guard let url = Bundle.main.url(forResource: "churn_predictions", withExtension: "json") else {
            print("No se encontró churn_predictions.json")
            return []
        }
        do {
            let data = try Data(contentsOf: url)
            return try JSONDecoder().decode([StoreClient].self, from: data)
        } catch {
            print("Error leyendo JSON:", error)
            return []
        }
    }
}

// MARK: - Filters & Tabs

enum RiskFilter: String, CaseIterable {
    case highest = "Mayor Riesgo"
    case lowest  = "Menor Riesgo"
}

enum AppTab {
    case store, dashboards, home, reports, profile
}

// MARK: - Main Tab

struct MainTabView: View {
    @State private var selectedTab: AppTab = .home
    private let clients = ClientDataLoader.loadClients()

    var body: some View {
        TabView(selection: $selectedTab) {
            StoreListView(clients: clients)
                .tabItem { Image(systemName: "storefront.fill"); Text("Tienda") }
                .tag(AppTab.store)

            ExecutiveDashboardView(clients: clients)
                .tabItem { Image(systemName: "square.grid.2x2.fill"); Text("Dash") }
                .tag(AppTab.dashboards)

            DashboardView(clients: clients, selectedTab: $selectedTab)
                .tabItem { Image(systemName: "house.fill"); Text("Inicio") }
                .tag(AppTab.home)

            ReportesView(clients: clients)
                .tabItem { Image(systemName: "folder.fill"); Text("Reportes") }
                .tag(AppTab.reports)

            EncuestasView()
                .tabItem { Image(systemName: "chart.bar.doc.horizontal.fill"); Text("Encuestas") }
                .tag(AppTab.profile)
        }
        .tint(AppTheme.wine)
    }
}

// MARK: - Agent Context + Service

// Un caso por pantalla — cada uno lleva los datos relevantes
// y construye su propio prompt especializado
enum AgentContext {

    // Tab Inicio — briefing general del día
    case home(clients: [StoreClient])

    // Tab Tiendas — lista filtrada activa
    case storeList(filtered: [StoreClient], levelFilter: String, month: String)

    // Detalle de un cliente específico
    case clientDetail(client: StoreClient)

    // Tab Dashboard ejecutivo
    case dashboard(clients: [StoreClient])

    // Construye el prompt según el contexto
    var prompt: String {
        switch self {

        case .home(let clients):
            let total    = clients.count
            let critical = clients.filter { $0.riskPercentage >= 80 }
            let medium   = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }
            let avgBoxes = clients.map(\.uniBoxesSoldM).reduce(0,+) / Double(max(total,1))
            let volCrit  = Int(Double(critical.count) * avgBoxes * 0.80)
            let volMed   = Int(Double(medium.count)   * avgBoxes * 0.40)
            let volTotal = volCrit + volMed
            let ceroTx   = clients.filter { $0.transactions == 0 }.count

            let terrGroups = Dictionary(grouping: clients, by: \.territoryD)
            let terrSorted5 = terrGroups
                .map { (n: $0.key, avg: $0.value.map(\.riskPercentage).reduce(0,+)/Double($0.value.count), c: $0.value.count) }
                .sorted { $0.avg > $1.avg }.prefix(5)
            var terrParts5: [String] = []
            for t in terrSorted5 {
                terrParts5.append("\(t.n) (\(String(format: "%.0f", t.avg))%, \(t.c) tiendas)")
            }
            let top5terr = terrParts5.joined(separator: ", ")

            let subGroups = Dictionary(grouping: clients, by: \.comercialSubchannelD)
            let subSorted3 = subGroups
                .map { (n: $0.key, avg: $0.value.map(\.riskPercentage).reduce(0,+)/Double($0.value.count)) }
                .sorted { $0.avg > $1.avg }.prefix(3)
            var subParts3: [String] = []
            for s in subSorted3 {
                subParts3.append("\(s.n) (\(String(format: "%.0f", s.avg))%)")
            }
            let top3sub = subParts3.joined(separator: ", ")

            return """
            Eres un agente experto en churn del Canal Tradicional de bebidas en México.
            El preventista acaba de abrir la app. Dale un briefing ejecutivo del día.

            DATOS DEL PERIODO:
            - Total tiendas: \(total)
            - Críticas (≥80%): \(critical.count) — volumen en riesgo: ~\(volCrit) cajas
            - Medias (50-79%): \(medium.count) — volumen en riesgo: ~\(volMed) cajas
            - Total volumen en riesgo: ~\(volTotal) cajas
            - Tiendas con 0 transacciones: \(ceroTx)
            - Top 5 territorios por riesgo: \(top5terr)
            - Top 3 subcanales por riesgo: \(top3sub)

            3 oraciones máximo:
            1. Estado general: territorios críticos y volumen en riesgo en cajas.
            2. Foco del día: dónde concentrar esfuerzo.
            3. Acción concreta inmediata.
            Sin emojis. Sin saludos. Máximo 65 palabras. Solo texto plano.
            """

        case .storeList(let filtered, let levelFilter, let month):
            let total    = filtered.count
            let critical = filtered.filter { $0.riskPercentage >= 80 }.count
            let medium   = filtered.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            let avgBoxes = filtered.map(\.uniBoxesSoldM).reduce(0,+) / Double(max(total,1))
            let vol      = Int(Double(critical) * avgBoxes * 0.80 + Double(medium) * avgBoxes * 0.40)

            let terrGroups = Dictionary(grouping: filtered, by: \.territoryD)
            let terrSorted3 = terrGroups
                .map { (n: $0.key, avg: $0.value.map(\.riskPercentage).reduce(0,+)/Double($0.value.count)) }
                .sorted { $0.avg > $1.avg }.prefix(3)
            var terrParts3: [String] = []
            for t in terrSorted3 {
                terrParts3.append("\(t.n) (\(String(format: "%.0f", t.avg))%)")
            }
            let topTerr = terrParts3.joined(separator: ", ")

            return """
            Eres un agente experto en churn del Canal Tradicional de bebidas en México.
            El preventista está viendo la lista filtrada de tiendas.

            FILTRO ACTIVO: Nivel "\(levelFilter)" · Mes \(month)
            DATOS DE LA VISTA ACTUAL:
            - Tiendas visibles: \(total)
            - Críticas: \(critical), Medias: \(medium)
            - Volumen en riesgo en esta vista: ~\(vol) cajas
            - Territorios predominantes: \(topTerr)

            2 oraciones:
            1. Qué representa este filtro y el volumen en riesgo de estas tiendas.
            2. Qué hacer con esta lista específica.
            Sin emojis. Sin saludos. Máximo 45 palabras. Solo texto plano.
            """

        case .clientDetail(let c):
            let drop = c.uniBoxesSoldM < 1
                ? "sin ventas este periodo"
                : "\(Int(c.uniBoxesSoldM)) cajas vendidas"

            return """
            Eres un agente experto en churn del Canal Tradicional de bebidas en México.
            El preventista está revisando el detalle de una tienda específica.

            DATOS DE LA TIENDA:
            - Territorio: \(c.territoryD)
            - Subcanal: \(c.comercialSubchannelD)
            - Tamaño: \(c.customerSize)
            - Riesgo actual: \(String(format:"%.1f",c.riskPercentage))% — \(c.riskLevel)
            - Segmento: \(c.segment)
            - Transacciones: \(c.transactions)
            - Volumen: \(drop)
            - Coolers activos: \(c.coolers)
            - Puertas: \(c.doors)

            3 oraciones:
            1. Diagnóstico: por qué esta tienda tiene este nivel de riesgo (menciona los datos específicos).
            2. Proyección: qué pasará el próximo periodo si no se actúa (habla de volumen en riesgo).
            3. Acción: qué debe hacer el preventista HOY en esta tienda.
            Sin emojis. Sin saludos. Máximo 65 palabras. Solo texto plano.
            """

        case .dashboard(let clients):
            let total    = clients.count
            let critical = clients.filter { $0.riskPercentage >= 80 }.count
            let medium   = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            let avgBoxes = clients.map(\.uniBoxesSoldM).reduce(0,+) / Double(max(total,1))
            let vol      = Int(Double(critical) * avgBoxes * 0.80 + Double(medium) * avgBoxes * 0.40)

            let terrGroups = Dictionary(grouping: clients, by: \.territoryD)
            let terrSorted = terrGroups
                .map { (n: $0.key, avg: $0.value.map(\.riskPercentage).reduce(0,+) / Double($0.value.count)) }
                .sorted { $0.avg > $1.avg }
                .prefix(3)
            var terrParts: [String] = []
            for t in terrSorted {
                let pct = String(format: "%.0f", t.avg)
                terrParts.append("\(t.n) (\(pct)%)")
            }
            let top3 = terrParts.joined(separator: ", ")

            return """
            Eres un agente experto en churn del Canal Tradicional de bebidas en México.
            El preventista está viendo el dashboard ejecutivo.

            RESUMEN EJECUTIVO:
            - Total tiendas: \(total)
            - Críticas: \(critical), Medias: \(medium)
            - Volumen total en riesgo: ~\(vol) cajas
            - Top 3 territorios críticos: \(top3)

            2 oraciones ejecutivas:
            1. Interpretación del estado global con el volumen en riesgo.
            2. Territorio o subcanal que más atención necesita y por qué.
            Sin emojis. Sin saludos. Máximo 45 palabras. Solo texto plano.
            """
        }
    }

    // Fallback local por contexto
    var fallback: String {
        switch self {
        case .home(let clients):
            let c = clients.filter { $0.riskPercentage >= 80 }.count
            let m = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            let avg = clients.map(\.uniBoxesSoldM).reduce(0,+) / Double(max(clients.count,1))
            let vol = Int(Double(c)*avg*0.80 + Double(m)*avg*0.40)
            let terrSorted = Dictionary(grouping: clients, by: \.territoryD)
                .map { (n: $0.key, avg: $0.value.map(\.riskPercentage).reduce(0,+)/Double($0.value.count)) }
                .sorted { $0.avg > $1.avg }
                .prefix(3)
            var topNames: [String] = []
            for t in terrSorted { topNames.append(t.n) }
            let top = topNames.joined(separator: ", ")
            return "\(c) tiendas en Crítico y \(m) en Medio en \(top). Volumen en riesgo proyectado: ~\(vol) cajas."

        case .storeList(let f, let lvl, _):
            let c = f.filter { $0.riskPercentage >= 80 }.count
            let m = f.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            return "Vista \(lvl): \(f.count) tiendas — \(c) críticas y \(m) en estado medio."

        case .clientDetail(let c):
            return "\(c.riskLevel) con \(String(format:"%.0f",c.riskPercentage))% de riesgo. " +
                   "\(c.transactions == 0 ? "Sin transacciones este periodo." : "\(c.transactions) transacciones registradas.") " +
                   "Visita prioritaria recomendada."

        case .dashboard(let clients):
            let c = clients.filter { $0.riskPercentage >= 80 }.count
            let m = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            return "\(c) tiendas críticas y \(m) en estado medio de un total de \(clients.count). Revisa territorios prioritarios."
        }
    }

    // Pills del header del banner
    var pills: [(label: String, color: Color)] {
        switch self {
        case .home(let clients):
            let c = clients.filter { $0.riskPercentage >= 80 }.count
            let m = clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count
            return [("\(c) críticos", AppTheme.wine), ("\(m) medios", AppTheme.softOrange)]
        case .storeList(let f, let lvl, _):
            return [("\(f.count) tiendas", AppTheme.wine), (lvl, AppTheme.softOrange)]
        case .clientDetail(let c):
            return [("\(String(format:"%.0f",c.riskPercentage))%", c.riskColor), (c.riskLevel, c.riskColor)]
        case .dashboard(let clients):
            let c = clients.filter { $0.riskPercentage >= 80 }.count
            return [("\(c) críticos", AppTheme.wine), ("\(clients.count) total", AppTheme.softGreen)]
        }
    }
}

struct AgentBannerService {
    static let apiKey   = "AQ.Ab8RN6I9rNZmJs9iogE5uaY-R1_KIqPBlx3Kq9OhUbOKCs5r7g"
    static let endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=\(apiKey)"

    static func analyze(context: AgentContext) async throws -> String {
        let body: [String: Any] = [
            "contents": [["parts": [["text": context.prompt]]]],
            "generationConfig": ["temperature": 0.3, "maxOutputTokens": 200]
        ]

        guard let url = URL(string: endpoint) else { throw GeminiError.invalidURL }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw GeminiError.badResponse }

        guard
            let json       = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"] as? [[String: Any]],
            let content    = candidates.first?["content"] as? [String: Any],
            let parts      = content["parts"] as? [[String: Any]],
            let text       = parts.first?["text"] as? String
        else { throw GeminiError.parseError }

        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

struct AgentBannerCard: View {
    let context: AgentContext

    @State private var message: String? = nil
    @State private var isLoading = true

    var body: some View {
        HStack(alignment: .top, spacing: 14) {

            ZStack {
                Circle().fill(AppTheme.wine.opacity(0.12)).frame(width: 42, height: 42)
                if isLoading {
                    ProgressView().tint(AppTheme.wine).scaleEffect(0.75)
                } else {
                    Image(systemName: "sparkles")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(AppTheme.wine)
                }
            }

            VStack(alignment: .leading, spacing: 6) {
                // Pills dinámicas según contexto
                HStack(spacing: 6) {
                    Text("Agente IA")
                        .font(.caption).fontWeight(.bold).foregroundStyle(AppTheme.wine)
                    ForEach(context.pills, id: \.label) { pill in
                        HStack(spacing: 4) {
                            Circle().fill(pill.color).frame(width: 5, height: 5)
                            Text(pill.label)
                                .font(.system(size: 10, weight: .semibold))
                                .foregroundStyle(pill.color)
                        }
                        .padding(.horizontal, 6).padding(.vertical, 2)
                        .background(pill.color.opacity(0.08)).clipShape(Capsule())
                    }
                }

                if isLoading {
                    VStack(alignment: .leading, spacing: 5) {
                        RoundedRectangle(cornerRadius: 3).fill(Color.gray.opacity(0.15))
                            .frame(height: 10).frame(maxWidth: .infinity)
                        RoundedRectangle(cornerRadius: 3).fill(Color.gray.opacity(0.15))
                            .frame(height: 10).frame(maxWidth: 200)
                    }
                } else {
                    Text(message ?? context.fallback)
                        .font(.caption)
                        .foregroundStyle(.primary)
                        .lineSpacing(3)
                        .fixedSize(horizontal: false, vertical: true)
                }
            }

            Spacer(minLength: 0)
        }
        .padding(14)
        .background(Color.white)
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16).strokeBorder(AppTheme.wine.opacity(0.15), lineWidth: 1))
        .shadow(color: AppTheme.wine.opacity(0.08), radius: 8, x: 0, y: 3)
        .task {
            do {
                message = try await AgentBannerService.analyze(context: context)
            } catch {
                message = context.fallback
            }
            isLoading = false
        }
    }
}

// MARK: - Dashboard

struct DashboardView: View {
    let clients: [StoreClient]
    @Binding var selectedTab: AppTab
    @State private var riskFilter: RiskFilter = .highest
    @State private var bannerVisible = true
    @State private var showAgentSheet = false

    private var top10: [StoreClient] {
        let sorted = riskFilter == .highest
            ? clients.sorted { $0.riskPercentage > $1.riskPercentage }
            : clients.sorted { $0.riskPercentage < $1.riskPercentage }
        return Array(sorted.prefix(10))
    }

    private var clientPairs: [[StoreClient]] {
        stride(from: 0, to: top10.count, by: 2).map {
            Array(top10[$0..<min($0 + 2, top10.count)])
        }
    }

    var body: some View {
        NavigationStack {
            ZStack(alignment: .trailing) {
                AppTheme.appBackground.ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 20) {
                        HeaderView()
                        RiskSummaryCard(clients: clients)

                        // Banner con detector de visibilidad
                        AgentBannerCard(context: .home(clients: clients))
                            .background(
                                GeometryReader { geo in
                                    Color.clear
                                        .onChange(of: geo.frame(in: .global).maxY) { _, maxY in
                                            withAnimation(.easeInOut(duration: 0.25)) {
                                                bannerVisible = maxY > 100
                                            }
                                        }
                                }
                            )

                        HStack {
                            Text("Top 10 Tienditas")
                                .font(.title3).fontWeight(.bold)
                            Spacer()
                            Text("\(riskFilter == .highest ? "Mayor" : "Menor") Riesgo")
                                .font(.caption).fontWeight(.semibold)
                                .foregroundStyle(riskFilter == .highest ? AppTheme.wine : AppTheme.softGreen)
                                .padding(.horizontal, 10).padding(.vertical, 4)
                                .background((riskFilter == .highest ? AppTheme.wine : AppTheme.softGreen).opacity(0.12))
                                .clipShape(Capsule())
                        }

                        Picker("Filtro", selection: $riskFilter) {
                            ForEach(RiskFilter.allCases, id: \.self) {
                                Text($0.rawValue).tag($0)
                            }
                        }
                        .pickerStyle(.segmented)

                        VStack(spacing: 14) {
                            ForEach(clientPairs, id: \.first?.id) { pair in
                                HStack(spacing: 14) {
                                    ForEach(pair) { client in
                                        NavigationLink {
                                            ClientDetailView(client: client)
                                        } label: {
                                            StoreRiskCard(client: client)
                                        }
                                        .buttonStyle(.plain)
                                    }
                                    if pair.count == 1 {
                                        Color.clear.frame(maxWidth: .infinity)
                                    }
                                }
                            }
                        }

                        Button {
                            selectedTab = .store
                        } label: {
                            HStack(spacing: 8) {
                                Text("Ver todas las tiendas").font(.subheadline).fontWeight(.semibold)
                                Image(systemName: "chevron.right").font(.subheadline)
                            }
                            .foregroundStyle(AppTheme.wine)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(AppTheme.wine.opacity(0.08))
                            .cornerRadius(14)
                            .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(AppTheme.wine.opacity(0.20), lineWidth: 1))
                        }
                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 18)
                    .padding(.bottom, 32)
                }

                // ── Floating Agent Tab ───────────────────────────────
                // Aparece solo cuando el banner ya no es visible
                if !bannerVisible {
                    Button {
                        showAgentSheet = true
                    } label: {
                        AgentLogoView()
                            .frame(width: 52, height: 52)
                            .background(Color.white)
                            .clipShape(
                                // Forma de pestaña — redondeada en la izquierda, plana en la derecha
                                RoundedRectangle(cornerRadius: 14)
                            )
                            .shadow(color: AppTheme.wine.opacity(0.25), radius: 10, x: -3, y: 0)
                    }
                    .offset(x: 8)  // Asoma ligeramente del borde derecho
                    .frame(maxHeight: .infinity, alignment: .center)
                    .transition(.move(edge: .trailing).combined(with: .opacity))
                    .zIndex(10)
                }
            }
            .navigationBarHidden(true)
            .sheet(isPresented: $showAgentSheet) {
                AgentSheetView(clients: clients)
                    .presentationDetents([.medium, .large])
                    .presentationDragIndicator(.visible)
            }
        }
    }
}

// ── Logo del agente en SVG-style SwiftUI ────────────────────────────────────
struct AgentLogoView: View {
    var body: some View {
        ZStack {
            // Círculo lupa
            Circle()
                .trim(from: 0.15, to: 1.0)
                .stroke(
                    LinearGradient(colors: [AppTheme.wine, AppTheme.wine.opacity(0.4)],
                                   startPoint: .top, endPoint: .bottom),
                    style: StrokeStyle(lineWidth: 3.5, lineCap: .round)
                )
                .rotationEffect(.degrees(-30))
                .frame(width: 28, height: 28)
                .offset(x: -1, y: -2)

            // Mango de lupa
            RoundedRectangle(cornerRadius: 2)
                .fill(LinearGradient(colors: [AppTheme.wine, AppTheme.wine.opacity(0.6)],
                                     startPoint: .top, endPoint: .bottom))
                .frame(width: 3, height: 10)
                .rotationEffect(.degrees(45))
                .offset(x: 9, y: 9)

            // Barras de chart dentro
            HStack(alignment: .bottom, spacing: 2.5) {
                ForEach([0.35, 0.55, 0.75, 0.90], id: \.self) { h in
                    RoundedRectangle(cornerRadius: 1)
                        .fill(LinearGradient(
                            colors: [AppTheme.wine, AppTheme.wine.opacity(0.3)],
                            startPoint: .top, endPoint: .bottom))
                        .frame(width: 3, height: 14 * h)
                }
            }
            .offset(x: -2, y: 1)
        }
        .frame(width: 52, height: 52)
    }
}

// ── Sheet que abre el agente desde el floating button ────────────────────────
struct AgentSheetView: View {
    let clients: [StoreClient]

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Handle + header
            HStack(spacing: 12) {
                AgentLogoView().frame(width: 44, height: 44)
                VStack(alignment: .leading, spacing: 2) {
                    Text("Churn Hunter Agent")
                        .font(.headline).fontWeight(.bold)
                    Text("Análisis autónomo del periodo")
                        .font(.caption).foregroundStyle(AppTheme.mutedText)
                }
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.top, 20)
            .padding(.bottom, 16)

            Divider()

            ScrollView(showsIndicators: false) {
                AgentBannerCard(context: .home(clients: clients))
                    .padding(16)
            }
        }
        .background(AppTheme.appBackground)
    }
}

// MARK: - Header

struct HeaderView: View {
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Hola, Preventista")
                    .font(.title2)
                    .fontWeight(.bold)

                Text("Ruta priorizada para hoy")
                    .font(.subheadline)
                    .foregroundStyle(AppTheme.mutedText)
            }

            Spacer()
        }
    }
}

// MARK: - Risk Summary Card

struct RiskSummaryCard: View {
    let clients: [StoreClient]

    private struct Slice: Identifiable {
        let id = UUID()
        let label: String
        let value: Double
        let color: Color
    }

    private var critical: Int { clients.filter { $0.riskPercentage >= 80 }.count }
    private var medium:   Int { clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count }
    private var low:      Int { clients.filter { $0.riskPercentage < 50 }.count }

    private var slices: [Slice] {[
        Slice(label: "Crítico", value: Double(critical), color: AppTheme.wine),
        Slice(label: "Medio",   value: Double(medium),   color: AppTheme.softOrange),
        Slice(label: "Bajo",    value: Double(low),      color: AppTheme.softGreen),
    ]}

    var body: some View {
        HStack(alignment: .top, spacing: 16) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Distribución de riesgo")
                    .font(.subheadline)
                    .foregroundStyle(AppTheme.mutedText)

                Text("$12 MM MXN")
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(AppTheme.wine)

                Text("modelo generado con datos reales")
                    .font(.callout)

                ForEach(slices) { slice in
                    HStack(spacing: 6) {
                        Circle().fill(slice.color).frame(width: 8, height: 8)
                        Text(slice.label).font(.caption).foregroundStyle(AppTheme.mutedText)
                        Spacer()
                        Text("\(Int(slice.value))").font(.caption).fontWeight(.bold).foregroundStyle(slice.color)
                    }
                }
            }

            Spacer()

            Chart(slices) { slice in
                SectorMark(
                    angle: .value("Clientes", slice.value),
                    innerRadius: .ratio(0.54),
                    angularInset: 2
                )
                .foregroundStyle(slice.color)
                .cornerRadius(4)
            }
            .chartLegend(.hidden)
            .chartBackground { _ in
                VStack(spacing: 0) {
                    Text("\(clients.count)")
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(.primary)
                    Text("tiendas")
                        .font(.caption2)
                        .foregroundStyle(AppTheme.mutedText)
                }
            }
            .frame(width: 100, height: 100)
        }
        .padding(20)
        .modernCard()
    }
}

// MARK: - Store Risk Card

struct StoreRiskCard: View {
    let client: StoreClient

    var body: some View {
        VStack(spacing: 0) {
            ZStack(alignment: .topTrailing) {
                LiquidGauge(
                    value: client.riskPercentage / 100,
                    color: client.riskColor,
                    size: 110,
                    showLabel: true
                )
                .frame(maxWidth: .infinity)
                .padding(.top, 18)
                .padding(.bottom, 10)

                Text(client.riskLevel)
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(client.riskColor)
                    .clipShape(Capsule())
                    .padding(8)
            }

            VStack(spacing: 5) {
                // Nombre inventado de la tienda
                Text(client.storeName)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                    .minimumScaleFactor(0.8)

                Text(client.comercialSubchannelD)
                    .font(.system(size: 10))
                    .foregroundStyle(AppTheme.mutedText)
                    .multilineTextAlignment(.center)
                    .lineLimit(1)

                Divider().padding(.horizontal, 12).padding(.vertical, 4)

                HStack(spacing: 0) {
                    MiniStat(icon: "cart.fill",   value: "\(client.transactions) tx", color: client.riskColor)
                    Divider().frame(height: 22)
                    MiniStat(icon: "shippingbox", value: "\(Int(client.uniBoxesSoldM)) cj", color: client.riskColor)
                    Divider().frame(height: 22)
                    MiniStat(icon: "snowflake",   value: "\(client.coolers)", color: client.riskColor)
                }
            }
            .padding(.horizontal, 10)
            .padding(.bottom, 14)
        }
        .background(AppTheme.cardBackground)
        .cornerRadius(AppTheme.cardCornerRadius)
        .shadow(color: client.riskColor.opacity(0.18), radius: 8, x: 0, y: 3)
        .overlay(
            RoundedRectangle(cornerRadius: AppTheme.cardCornerRadius)
                .strokeBorder(client.riskColor.opacity(0.20), lineWidth: 1)
        )
    }
}

private struct MiniStat: View {
    let icon: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 3) {
            Image(systemName: icon).font(.system(size: 10)).foregroundStyle(color)
            Text(value).font(.system(size: 10, weight: .semibold))
        }
        .frame(maxWidth: .infinity)
    }
}

// MARK: - Liquid Gauge

struct LiquidGauge: View {
    let value: Double
    let color: Color
    let size: CGFloat
    var showLabel: Bool = true

    @State private var waveOffset: CGFloat = 0
    @State private var appeared = false

    private var fill: CGFloat {
        appeared ? CGFloat(max(0, min(value, 1))) : 0
    }

    var body: some View {
        ZStack {
            Circle().fill(color.opacity(0.08))
            LiquidWaveShape(fillFraction: fill, waveOffset: waveOffset)
                .fill(color.opacity(0.85)).clipShape(Circle())
            LiquidWaveShape(fillFraction: fill, waveOffset: waveOffset + .pi * 0.6)
                .fill(color.opacity(0.28)).clipShape(Circle())
            if showLabel {
                Text("\(Int(value * 100))%")
                    .font(.system(size: size * 0.26, weight: .black, design: .rounded))
                    .foregroundStyle(.white)
                    .shadow(color: color.opacity(0.9), radius: 3, x: 0, y: 0)
            }
            Circle().strokeBorder(color.opacity(0.30), lineWidth: 2)
        }
        .frame(width: size, height: size)
        .onAppear {
            withAnimation(.easeOut(duration: 1.0)) { appeared = true }
            withAnimation(.linear(duration: 2.2).repeatForever(autoreverses: false)) { waveOffset = .pi * 2 }
        }
    }
}

struct LiquidWaveShape: Shape {
    var fillFraction: CGFloat
    var waveOffset: CGFloat

    var animatableData: AnimatablePair<CGFloat, CGFloat> {
        get { AnimatablePair(fillFraction, waveOffset) }
        set { fillFraction = newValue.first; waveOffset = newValue.second }
    }

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let waveHeight = rect.height * 0.055
        let waterY = rect.height * (1 - fillFraction)
        let steps = Int(rect.width)

        path.move(to: CGPoint(x: 0, y: rect.height))
        path.addLine(to: CGPoint(x: 0, y: waterY))
        for i in 0...steps {
            let x = CGFloat(i)
            let y = waterY + sin((x / rect.width) * .pi * 2 + waveOffset) * waveHeight
            path.addLine(to: CGPoint(x: x, y: y))
        }
        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        path.closeSubpath()
        return path
    }
}

// MARK: - Client Detail

struct ClientDetailView: View {
    let client: StoreClient

    var body: some View {
        ZStack {
            AppTheme.appBackground.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 20) {
                    ClientHeaderCard(client: client)

                    HStack(spacing: 12) {
                        MetricCard(title: "Coolers",    value: "\(client.coolers)",        icon: "snowflake")
                        MetricCard(title: "Territorio", value: client.territoryD,           icon: "map.fill")
                    }
                    HStack(spacing: 12) {
                        MetricCard(title: "Subcanal",  value: client.comercialSubchannelD, icon: "tag.fill")
                        MetricCard(title: "Cajas/mes", value: "\(Int(client.uniBoxesSoldM)) cj", icon: "shippingbox.fill")
                    }
                    HStack(spacing: 12) {
                        MetricCard(title: "Transacciones", value: "\(client.transactions)", icon: "cart.fill")
                        MetricCard(title: "Puertas",       value: "\(client.doors)",        icon: "door.left.hand.open")
                    }

                    MetricCard(title: "Tamaño cliente", value: client.customerSize, icon: "person.3.fill", isWide: true)

                    AgentBannerCard(context: .clientDetail(client: client))

                    // ID real del cliente — solo visible en detalle
                    VStack(alignment: .leading, spacing: 6) {
                        Text("ID del cliente")
                            .font(.caption)
                            .foregroundStyle(AppTheme.mutedText)
                        Text(client.customerId)
                            .font(.system(size: 11, design: .monospaced))
                            .foregroundStyle(AppTheme.mutedText)
                            .lineLimit(2)
                            .minimumScaleFactor(0.7)
                    }
                    .padding(14)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .modernCard()

                    GeminiInsightCard(client: client)
                }
                .padding(20)
                .padding(.bottom, 32)
            }
        }
        .navigationTitle(client.storeName)
        .navigationBarTitleDisplayMode(.inline)
    }
}

// MARK: - Client Header Card

struct ClientHeaderCard: View {
    let client: StoreClient

    var body: some View {
        VStack(spacing: 16) {
            HStack {
                LiquidGauge(value: client.riskPercentage / 100, color: client.riskColor, size: 80, showLabel: true)
                Spacer()
                VStack(alignment: .trailing, spacing: 6) {
                    Text("\(Int(client.riskPercentage))%")
                        .font(.system(size: 36, weight: .black, design: .rounded))
                        .foregroundStyle(client.riskColor)
                    Text(client.riskLevel)
                        .font(.caption).fontWeight(.bold).foregroundStyle(.white)
                        .padding(.horizontal, 12).padding(.vertical, 6)
                        .background(client.riskColor).clipShape(Capsule())
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(client.storeName)
                    .font(.title2).fontWeight(.bold)
                Text("Canal Tradicional · Modelo de riesgo de churn")
                    .font(.subheadline).foregroundStyle(AppTheme.mutedText)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .padding(20)
        .modernCard()
    }
}

// MARK: - Metric Card

struct MetricCard: View {
    let title: String
    let value: String
    let icon: String
    var isWide: Bool = false

    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle().fill(AppTheme.wine.opacity(0.10)).frame(width: 40, height: 40)
                Image(systemName: icon).font(.headline).foregroundStyle(AppTheme.wine)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(title).font(.caption).foregroundStyle(AppTheme.mutedText)
                Text(value).font(.headline).fontWeight(.bold).lineLimit(1).minimumScaleFactor(0.7)
            }
            Spacer()
        }
        .padding(14)
        .frame(maxWidth: .infinity)
        .modernCard()
    }
}

// MARK: - Gemini Insight Card

// MARK: - Gemini Service

struct GeminiService {
    // 🔑 Reemplaza con tu API key de https://aistudio.google.com/app/apikey
    static let apiKey = "AQ.Ab8RN6I9rNZmJs9iogE5uaY-R1_KIqPBlx3Kq9OhUbOKCs5r7g"
    static let endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=\(apiKey)"

    static func analyze(client: StoreClient) async throws -> AgentInsight {
        let prompt = """
        Eres un agente experto en análisis de churn para el Canal Tradicional de bebidas en México.
        Analiza los datos de esta tienda y genera una predicción autónoma.

        DATOS DE LA TIENDA:
        - Nombre: \(client.storeName)
        - Territorio: \(client.territoryD)
        - Subcanal comercial: \(client.comercialSubchannelD)
        - Tamaño del cliente: \(client.customerSize)
        - Riesgo actual: \(String(format: "%.1f", client.riskPercentage))% (\(client.riskLevel))
        - Segmento actual: \(client.segment)
        - Coolers activos: \(client.coolers)
        - Puertas: \(client.doors)
        - Transacciones del mes: \(client.transactions)
        - Cajas vendidas el mes: \(String(format: "%.0f", client.uniBoxesSoldM))

        INSTRUCCIONES:
        Basándote en estos datos, predice si esta tienda se convertirá en Detractor el próximo mes.
        Un Detractor es una tienda con riesgo >= 80% que dejará de comprar.

        Responde ÚNICAMENTE con este JSON válido, sin texto adicional:
        {
          "prediction": "Promotor o Pasivo o Detractor",
          "confidence": número del 0 al 100,
          "trend": "mejorando o estable o deteriorando",
          "analysis": "2 oraciones máximo explicando el riesgo principal y por qué podría convertirse en detractor",
          "action": "1 acción concreta y específica que debe hacer el preventista esta semana",
          "priority": "Alta o Media o Baja"
        }
        """

        let body: [String: Any] = [
            "contents": [
                ["parts": [["text": prompt]]]
            ],
            "generationConfig": [
                "temperature": 0.3,
                "maxOutputTokens": 300
            ]
        ]

        guard let url = URL(string: endpoint) else { throw GeminiError.invalidURL }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: request)

        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            throw GeminiError.badResponse
        }

        // Extraer el texto de la respuesta de Gemini
        guard
            let json     = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"] as? [[String: Any]],
            let content  = candidates.first?["content"] as? [String: Any],
            let parts    = content["parts"] as? [[String: Any]],
            let text     = parts.first?["text"] as? String
        else { throw GeminiError.parseError }

        // Limpiar posibles backticks que Gemini a veces agrega
        let clean = text
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "```json", with: "")
            .replacingOccurrences(of: "```", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        guard
            let jsonData  = clean.data(using: .utf8),
            let parsed    = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any]
        else { throw GeminiError.parseError }

        return AgentInsight(
            prediction:  parsed["prediction"]  as? String ?? "—",
            confidence:  parsed["confidence"]  as? Int    ?? 0,
            trend:       parsed["trend"]       as? String ?? "estable",
            analysis:    parsed["analysis"]    as? String ?? "Sin análisis disponible.",
            action:      parsed["action"]      as? String ?? "Realizar visita de seguimiento.",
            priority:    parsed["priority"]    as? String ?? "Media"
        )
    }
}

enum GeminiError: Error {
    case invalidURL, badResponse, parseError
}

struct AgentInsight {
    let prediction: String
    let confidence: Int
    let trend: String
    let analysis: String
    let action: String
    let priority: String

    var predictionColor: Color {
        switch prediction {
        case "Detractor": return AppTheme.wine
        case "Pasivo":    return AppTheme.softOrange
        default:          return AppTheme.softGreen
        }
    }

    var trendIcon: String {
        switch trend {
        case "deteriorando": return "arrow.down.right.circle.fill"
        case "mejorando":    return "arrow.up.right.circle.fill"
        default:             return "minus.circle.fill"
        }
    }

    var trendColor: Color {
        switch trend {
        case "deteriorando": return AppTheme.wine
        case "mejorando":    return AppTheme.softGreen
        default:             return AppTheme.softOrange
        }
    }
}

// MARK: - Gemini Insight Card

struct GeminiInsightCard: View {
    let client: StoreClient

    @State private var insight: AgentInsight? = nil
    @State private var isLoading = true
    @State private var errorMsg: String? = nil

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {

            // ── Header ───────────────────────────────────
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(AppTheme.wine.opacity(0.12))
                        .frame(width: 44, height: 44)
                    if isLoading {
                        ProgressView()
                            .tint(AppTheme.wine)
                            .scaleEffect(0.8)
                    } else {
                        Image(systemName: "sparkles")
                            .font(.title3)
                            .foregroundStyle(AppTheme.wine)
                    }
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text("Churn Hunter Agent")
                        .font(.headline).fontWeight(.bold)
                    Text(isLoading ? "Analizando con IA..." : "Análisis autónomo generado")
                        .font(.caption).foregroundStyle(AppTheme.mutedText)
                }
                Spacer()
                // Badge de confianza
                if let ins = insight {
                    Text("\(ins.confidence)% conf.")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8).padding(.vertical, 4)
                        .background(ins.predictionColor)
                        .clipShape(Capsule())
                }
            }

            if isLoading {
                // Skeleton mientras carga
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(0..<3, id: \.self) { i in
                        RoundedRectangle(cornerRadius: 4)
                            .fill(Color.gray.opacity(0.12))
                            .frame(height: 12)
                            .frame(maxWidth: i == 2 ? .infinity * 0.6 : .infinity)
                    }
                }

            } else if let err = errorMsg {
                HStack(spacing: 8) {
                    Image(systemName: "exclamationmark.triangle").foregroundStyle(AppTheme.softOrange)
                    Text(err).font(.caption).foregroundStyle(AppTheme.mutedText)
                }

            } else if let ins = insight {

                // ── Predicción principal ──────────────────
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Predicción próximo mes")
                            .font(.caption2).foregroundStyle(AppTheme.mutedText)
                        Text(ins.prediction)
                            .font(.system(size: 18, weight: .black, design: .rounded))
                            .foregroundStyle(ins.predictionColor)
                    }
                    Spacer()
                    // Tendencia
                    HStack(spacing: 4) {
                        Image(systemName: ins.trendIcon)
                            .foregroundStyle(ins.trendColor)
                        Text(ins.trend.capitalized)
                            .font(.caption).fontWeight(.semibold)
                            .foregroundStyle(ins.trendColor)
                    }
                    .padding(.horizontal, 10).padding(.vertical, 6)
                    .background(ins.trendColor.opacity(0.10))
                    .cornerRadius(10)
                }

                Divider()

                // ── Análisis narrativo ────────────────────
                Text(ins.analysis)
                    .font(.subheadline)
                    .lineSpacing(4)
                    .fixedSize(horizontal: false, vertical: true)

                // ── Acción recomendada ────────────────────
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "checkmark.seal.fill")
                        .foregroundStyle(AppTheme.wine)
                        .font(.subheadline)
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Acción recomendada")
                            .font(.caption2).foregroundStyle(AppTheme.mutedText)
                        Text(ins.action)
                            .font(.caption).fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(12)
                .background(AppTheme.wine.opacity(0.05))
                .cornerRadius(10)

                // ── Prioridad ─────────────────────────────
                HStack(spacing: 6) {
                    Circle().fill(ins.predictionColor).frame(width: 7, height: 7)
                    Text("Prioridad \(ins.priority)")
                        .font(.caption2).fontWeight(.semibold)
                        .foregroundStyle(ins.predictionColor)
                }
            }
        }
        .padding(20)
        .background(Color.white)
        .cornerRadius(18)
        .overlay(RoundedRectangle(cornerRadius: 18).strokeBorder(AppTheme.wine.opacity(0.20), lineWidth: 1.2))
        .shadow(color: AppTheme.wine.opacity(0.14), radius: 12, x: 0, y: 5)
        .task {
            // Se llama automáticamente al aparecer la vista, sin que el usuario haga nada
            do {
                insight = try await GeminiService.analyze(client: client)
            } catch {
                errorMsg = "No se pudo conectar con el agente. Verifica tu API key."
            }
            isLoading = false
        }
    }
}

struct InsightRow: View {
    let icon: String
    let text: String

    var body: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: icon).font(.caption).foregroundStyle(AppTheme.wine).frame(width: 18)
            Text(text).font(.caption).fixedSize(horizontal: false, vertical: true)
        }
    }
}

// MARK: - Store List View

enum StoreSort: String, CaseIterable {
    case riskDesc  = "Mayor riesgo"
    case riskAsc   = "Menor riesgo"
    case nameAsc   = "Nombre A-Z"
    case nameDesc  = "Nombre Z-A"
}

enum RiskLevelFilter: String, CaseIterable {
    case all      = "Todos"
    case critical = "Crítico"
    case medium   = "Medio"
    case low      = "Bajo"
}

struct StoreListView: View {
    let clients: [StoreClient]

    @State private var searchText    = ""
    @State private var sortBy        = StoreSort.riskDesc
    @State private var levelFilter   = RiskLevelFilter.all
    @State private var showFilters   = false
    @State private var selectedMonth = "Todos"

    // Meses únicos extraídos del JSON, ordenados
    private var availableMonths: [String] {
        let raw = Array(Set(clients.map(\.calmonth))).sorted()
        return ["Todos"] + raw
    }

    // Formato legible: "202401" → "Ene 24"
    private func monthLabel(_ raw: String) -> String {
        guard raw != "Todos", raw.count == 6,
              let year  = Int(raw.prefix(4)),
              let month = Int(raw.suffix(2))
        else { return raw }
        let names = ["Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic"]
        guard month >= 1 && month <= 12 else { return raw }
        return "\(names[month-1]) \(String(year).suffix(2))"
    }

    private var filtered: [StoreClient] {
        var result = clients

        // Filtro por mes
        if selectedMonth != "Todos" {
            result = result.filter { $0.calmonth == selectedMonth }
        }

        // Búsqueda
        if !searchText.isEmpty {
            let q = searchText.lowercased()
            result = result.filter {
                $0.storeName.lowercased().contains(q) ||
                $0.territoryD.lowercased().contains(q) ||
                $0.comercialSubchannelD.lowercased().contains(q)
            }
        }

        // Filtro por nivel
        switch levelFilter {
        case .critical: result = result.filter { $0.riskPercentage >= 80 }
        case .medium:   result = result.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }
        case .low:      result = result.filter { $0.riskPercentage < 50 }
        case .all:      break
        }

        // Ordenamiento
        switch sortBy {
        case .riskDesc: result.sort { $0.riskPercentage > $1.riskPercentage }
        case .riskAsc:  result.sort { $0.riskPercentage < $1.riskPercentage }
        case .nameAsc:  result.sort { $0.storeName < $1.storeName }
        case .nameDesc: result.sort { $0.storeName > $1.storeName }
        }

        return result
    }

    private var stats: (critical: Int, medium: Int, low: Int) {
        let base = selectedMonth == "Todos" ? clients : clients.filter { $0.calmonth == selectedMonth }
        return (
            base.filter { $0.riskPercentage >= 80 }.count,
            base.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count,
            base.filter { $0.riskPercentage < 50 }.count
        )
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()

                VStack(spacing: 0) {

                    // Header
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Tiendas")
                                    .font(.title2).fontWeight(.bold)
                                Text("\(filtered.count) de \(clients.count) tienditas")
                                    .font(.caption).foregroundStyle(AppTheme.mutedText)
                            }
                            Spacer()
                            Button {
                                withAnimation(.spring(response: 0.3)) { showFilters.toggle() }
                            } label: {
                                ZStack(alignment: .topTrailing) {
                                    Image(systemName: "slider.horizontal.3")
                                        .font(.system(size: 18, weight: .semibold))
                                        .foregroundStyle(AppTheme.wine)
                                        .padding(10)
                                        .background(AppTheme.wine.opacity(0.10))
                                        .clipShape(Circle())
                                    if levelFilter != .all {
                                        Circle().fill(AppTheme.wine)
                                            .frame(width: 8, height: 8)
                                            .offset(x: 2, y: -2)
                                    }
                                }
                            }
                        }

                        // Barra de búsqueda
                        HStack(spacing: 10) {
                            Image(systemName: "magnifyingglass").foregroundStyle(AppTheme.mutedText)
                            TextField("Buscar tienda, territorio o subcanal...", text: $searchText)
                                .font(.subheadline)
                            if !searchText.isEmpty {
                                Button { searchText = "" } label: {
                                    Image(systemName: "xmark.circle.fill").foregroundStyle(AppTheme.mutedText)
                                }
                            }
                        }
                        .padding(.horizontal, 12).padding(.vertical, 10)
                        .background(Color.white).cornerRadius(12)
                        .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)

                        // ── Chips de mes — siempre visibles ──────────
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 8) {
                                ForEach(availableMonths, id: \.self) { month in
                                    Button {
                                        withAnimation(.spring(response: 0.25)) {
                                            selectedMonth = month
                                        }
                                    } label: {
                                        Text(monthLabel(month))
                                            .font(.caption).fontWeight(selectedMonth == month ? .bold : .regular)
                                            .foregroundStyle(selectedMonth == month ? .white : AppTheme.wine)
                                            .padding(.horizontal, 14).padding(.vertical, 7)
                                            .background(selectedMonth == month ? AppTheme.wine : AppTheme.wine.opacity(0.08))
                                            .clipShape(Capsule())
                                    }
                                }
                            }
                        }

                        // Panel de filtros expandible
                        if showFilters {
                            VStack(alignment: .leading, spacing: 10) {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text("Nivel de riesgo")
                                        .font(.caption).fontWeight(.semibold).foregroundStyle(AppTheme.mutedText)
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack(spacing: 8) {
                                            ForEach(RiskLevelFilter.allCases, id: \.self) { f in
                                                FilterChip(label: f.rawValue, isSelected: levelFilter == f, color: chipColor(f)) { levelFilter = f }
                                            }
                                        }
                                    }
                                }
                                VStack(alignment: .leading, spacing: 6) {
                                    Text("Ordenar por")
                                        .font(.caption).fontWeight(.semibold).foregroundStyle(AppTheme.mutedText)
                                    ScrollView(.horizontal, showsIndicators: false) {
                                        HStack(spacing: 8) {
                                            ForEach(StoreSort.allCases, id: \.self) { s in
                                                FilterChip(label: s.rawValue, isSelected: sortBy == s, color: AppTheme.wine) { sortBy = s }
                                            }
                                        }
                                    }
                                }
                            }
                            .padding(14)
                            .background(Color.white).cornerRadius(14)
                            .shadow(color: .black.opacity(0.05), radius: 4, x: 0, y: 2)
                            .transition(.opacity.combined(with: .move(edge: .top)))
                        }

                        // Chips de resumen
                        HStack(spacing: 8) {
                            SummaryChip(count: stats.critical, label: "Crítico", color: AppTheme.wine)
                            SummaryChip(count: stats.medium,   label: "Medio",   color: AppTheme.softOrange)
                            SummaryChip(count: stats.low,      label: "Bajo",    color: AppTheme.softGreen)
                        }
                    }
                    .padding(.horizontal, 16).padding(.top, 16).padding(.bottom, 12)

                    // Lista
                    if filtered.isEmpty {
                        Spacer()
                        VStack(spacing: 14) {
                            Image(systemName: "magnifyingglass")
                                .font(.system(size: 40)).foregroundStyle(AppTheme.mutedText.opacity(0.4))
                            Text("Sin resultados").font(.headline).foregroundStyle(AppTheme.mutedText)
                            Text("Intenta con otro término o quita los filtros.")
                                .font(.caption).foregroundStyle(AppTheme.mutedText).multilineTextAlignment(.center)
                        }
                        Spacer()
                    } else {
                        List {
                            ForEach(filtered) { client in
                                NavigationLink { ClientDetailView(client: client) } label: {
                                    StoreListRow(client: client)
                                }
                                .listRowBackground(Color.clear)
                                .listRowSeparator(.hidden)
                                .listRowInsets(EdgeInsets(top: 5, leading: 16, bottom: 5, trailing: 16))
                            }
                        }
                        .listStyle(.plain)
                        .scrollIndicators(.hidden)
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }

    private func chipColor(_ f: RiskLevelFilter) -> Color {
        switch f {
        case .critical: return AppTheme.wine
        case .medium:   return AppTheme.softOrange
        case .low:      return AppTheme.softGreen
        case .all:      return AppTheme.wine
        }
    }
}

// MARK: - Store List Row

struct StoreListRow: View {
    let client: StoreClient

    var body: some View {
        HStack(spacing: 14) {

            // Mini gauge circular
            ZStack {
                Circle()
                    .stroke(client.riskColor.opacity(0.15), lineWidth: 4)
                    .frame(width: 52, height: 52)
                Circle()
                    .trim(from: 0, to: CGFloat(client.riskPercentage / 100))
                    .stroke(client.riskColor, style: StrokeStyle(lineWidth: 4, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .frame(width: 52, height: 52)
                Text("\(Int(client.riskPercentage))%")
                    .font(.system(size: 11, weight: .black, design: .rounded))
                    .foregroundStyle(client.riskColor)
            }

            // Info
            VStack(alignment: .leading, spacing: 3) {
                Text(client.storeName)
                    .font(.subheadline).fontWeight(.semibold)
                    .foregroundStyle(.primary)
                    .lineLimit(1)

                HStack(spacing: 4) {
                    Image(systemName: "mappin.circle.fill")
                        .font(.system(size: 10))
                        .foregroundStyle(AppTheme.mutedText)
                    Text(client.territoryD)
                        .font(.caption).foregroundStyle(AppTheme.mutedText)
                        .lineLimit(1)
                }

                HStack(spacing: 4) {
                    Image(systemName: "tag.fill")
                        .font(.system(size: 10))
                        .foregroundStyle(AppTheme.mutedText)
                    Text(client.comercialSubchannelD)
                        .font(.caption).foregroundStyle(AppTheme.mutedText)
                        .lineLimit(1)
                }
            }

            Spacer()

            // Badge nivel
            VStack(alignment: .trailing, spacing: 6) {
                Text(client.riskLevel)
                    .font(.system(size: 10, weight: .bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 8).padding(.vertical, 3)
                    .background(client.riskColor)
                    .clipShape(Capsule())

                HStack(spacing: 4) {
                    Image(systemName: "snowflake")
                        .font(.system(size: 9))
                        .foregroundStyle(AppTheme.mutedText)
                    Text("\(client.coolers)")
                        .font(.caption2).foregroundStyle(AppTheme.mutedText)
                    Image(systemName: "cart.fill")
                        .font(.system(size: 9))
                        .foregroundStyle(AppTheme.mutedText)
                    Text("\(client.transactions)")
                        .font(.caption2).foregroundStyle(AppTheme.mutedText)
                }
            }
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .background(Color.white)
        .cornerRadius(16)
        .shadow(color: client.riskColor.opacity(0.08), radius: 6, x: 0, y: 2)
    }
}

// MARK: - Filter Chip

struct FilterChip: View {
    let label: String
    let isSelected: Bool
    let color: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            Text(label)
                .font(.caption).fontWeight(isSelected ? .bold : .regular)
                .foregroundStyle(isSelected ? .white : color)
                .padding(.horizontal, 14).padding(.vertical, 7)
                .background(isSelected ? color : color.opacity(0.10))
                .clipShape(Capsule())
        }
    }
}

// MARK: - Summary Chip

struct SummaryChip: View {
    let count: Int
    let label: String
    let color: Color

    var body: some View {
        HStack(spacing: 5) {
            Circle().fill(color).frame(width: 7, height: 7)
            Text("\(count) \(label)")
                .font(.caption2).fontWeight(.semibold)
                .foregroundStyle(color)
        }
        .padding(.horizontal, 10).padding(.vertical, 5)
        .background(color.opacity(0.10))
        .clipShape(Capsule())
    }
}

// MARK: - Executive Dashboard View

struct ExecutiveDashboardView: View {
    let clients: [StoreClient]

    // ── Computed ────────────────────────────────────────────────────────
    private var total:        Int    { clients.count }
    private var critical:     Int    { clients.filter { $0.riskPercentage >= 80 }.count }
    private var medium:       Int    { clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count }
    private var low:          Int    { clients.filter { $0.riskPercentage < 50 }.count }
    private var avgRisk:      Double { clients.isEmpty ? 0 : clients.map(\.riskPercentage).reduce(0,+) / Double(total) }
    private var totalBoxes:   Int    { Int(clients.map(\.uniBoxesSoldM).reduce(0,+)) }
    private var totalTx:      Int    { clients.map(\.transactions).reduce(0,+) }
    private var totalCoolers: Int    { clients.map(\.coolers).reduce(0,+) }

    // Risk buckets 0-9 (each = 10 pp range)
    private var riskBuckets: [DashBucket] {
        (0..<10).map { i in
            let lo = Double(i*10), hi = Double((i+1)*10)
            let n = clients.filter { $0.riskPercentage >= lo && (i == 9 ? $0.riskPercentage <= hi : $0.riskPercentage < hi) }.count
            let color: Color = i >= 8 ? AppTheme.wine : i >= 5 ? AppTheme.softOrange : AppTheme.softGreen
            return DashBucket(label: "\(i*10)", value: n, color: color)
        }
    }

    // Top 5 territories by avg risk
    private var topTerritories: [TerritoryData] {
        Dictionary(grouping: clients, by: \.territoryD)
            .map { key, vals in
                TerritoryData(
                    name: key,
                    avgRisk: vals.map(\.riskPercentage).reduce(0,+) / Double(vals.count),
                    count: vals.count
                )
            }
            .sorted { $0.avgRisk > $1.avgRisk }
            .prefix(5).map { $0 }
    }

    // Top 5 critical stores
    private var topCritical: [StoreClient] {
        Array(clients.sorted { $0.riskPercentage > $1.riskPercentage }.prefix(5))
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {

                        // ── 1. Header ────────────────────────────────
                        DashHeader()
                            .padding(.horizontal, 20)
                            .padding(.top, 8)

                        VStack(alignment: .leading, spacing: 20) {

                            // ── 2. Arc KPI row (Walk/Sleep style) ────
                            HStack(spacing: 12) {
                                ArcKpiCard(
                                    title: "Riesgo Prom.",
                                    value: "\(Int(avgRisk))%",
                                    subtitle: "de 100%",
                                    pct: avgRisk / 100,
                                    icon: "exclamationmark.triangle.fill",
                                    color: avgRisk >= 80 ? AppTheme.wine : avgRisk >= 50 ? AppTheme.softOrange : AppTheme.softGreen
                                )
                                ArcKpiCard(
                                    title: "Coolers",
                                    value: "\(totalCoolers)",
                                    subtitle: "\(total) tiendas",
                                    pct: min(Double(totalCoolers) / Double(max(total * 3, 1)), 1.0),
                                    icon: "snowflake",
                                    color: Color(red: 0.20, green: 0.45, blue: 0.85)
                                )
                            }

                            // ── 4. Mini KPI grid (Calories/Steps style) ──
                            HStack(spacing: 12) {
                                MiniKpiCard(title: "Cajas",   value: "\(totalBoxes)", icon: "shippingbox.fill",  color: AppTheme.softGreen,
                                            sparkValues: riskBuckets.prefix(5).map { Double($0.value) })
                                MiniKpiCard(title: "Transacciones", value: "\(totalTx)", icon: "cart.fill", color: AppTheme.softOrange,
                                            sparkValues: riskBuckets.suffix(5).map { Double($0.value) })
                            }

                            // ── 5. Distribución de riesgo (area chart) ─
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Distribución de Riesgo")
                                            .font(.subheadline).fontWeight(.bold)
                                        Text("Clientes por rango (%)")
                                            .font(.caption2).foregroundStyle(AppTheme.mutedText)
                                    }
                                    Spacer()
                                    // Legend pills
                                    HStack(spacing: 6) {
                                        LegendPill(color: AppTheme.softGreen, label: "Bajo")
                                        LegendPill(color: AppTheme.softOrange, label: "Medio")
                                        LegendPill(color: AppTheme.wine, label: "Crítico")
                                    }
                                }

                                Chart {
                                    ForEach(riskBuckets) { b in
                                        AreaMark(
                                            x: .value("Rango", b.label),
                                            y: .value("Clientes", b.value)
                                        )
                                        .foregroundStyle(
                                            LinearGradient(
                                                colors: [b.color.opacity(0.45), b.color.opacity(0.05)],
                                                startPoint: .top, endPoint: .bottom
                                            )
                                        )
                                        .interpolationMethod(.catmullRom)

                                        LineMark(
                                            x: .value("Rango", b.label),
                                            y: .value("Clientes", b.value)
                                        )
                                        .foregroundStyle(b.color)
                                        .lineStyle(StrokeStyle(lineWidth: 2.5))
                                        .interpolationMethod(.catmullRom)

                                        PointMark(
                                            x: .value("Rango", b.label),
                                            y: .value("Clientes", b.value)
                                        )
                                        .foregroundStyle(b.color)
                                        .symbolSize(30)
                                    }
                                }
                                .chartXAxis {
                                    AxisMarks(values: .automatic(desiredCount: 5)) { val in
                                        AxisValueLabel {
                                            if let s = val.as(String.self) {
                                                Text("\(s)%").font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
                                            }
                                        }
                                    }
                                }
                                .chartYAxis {
                                    AxisMarks(position: .leading, values: .automatic(desiredCount: 4)) { _ in
                                        AxisGridLine(stroke: StrokeStyle(lineWidth: 0.5, dash: [4]))
                                            .foregroundStyle(Color.gray.opacity(0.2))
                                        AxisValueLabel().font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
                                    }
                                }
                                .frame(height: 170)
                            }
                            .padding(16)
                            .modernCard()

                            // ── 6. Top territorios (Working Progress style) ──
                            VStack(alignment: .leading, spacing: 12) {
                                HStack {
                                    Text("Territorios en Riesgo")
                                        .font(.subheadline).fontWeight(.bold)
                                    Spacer()
                                    Text("Top 5")
                                        .font(.caption2).fontWeight(.semibold)
                                        .foregroundStyle(AppTheme.wine)
                                        .padding(.horizontal, 8).padding(.vertical, 3)
                                        .background(AppTheme.wine.opacity(0.10))
                                        .clipShape(Capsule())
                                }

                                ForEach(topTerritories) { t in
                                    TerritoryProgressRow(data: t)
                                }
                            }
                            .padding(16)
                            .modernCard()

                            // ── 7. Tiendas críticas (Latest Workout style) ──
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    Text("Tiendas Críticas")
                                        .font(.subheadline).fontWeight(.bold)
                                    Spacer()
                                    Text("Ver todas")
                                        .font(.caption).foregroundStyle(AppTheme.wine)
                                }

                                ForEach(topCritical) { client in
                                    NavigationLink { ClientDetailView(client: client) } label: {
                                        CriticalStoreRow(client: client)
                                    }
                                    .buttonStyle(.plain)

                                    if client.id != topCritical.last?.id {
                                        Divider().padding(.leading, 56)
                                    }
                                }
                            }
                            .padding(16)
                            .modernCard()

                        }
                        .padding(.horizontal, 20)
                        .padding(.top, 8)
                        .padding(.bottom, 32)
                    }
                }
            }
            .navigationBarHidden(true)
        }
    }
}

// MARK: - Dashboard Data Models

private struct DashBucket: Identifiable {
    let id = UUID()
    let label: String
    let value: Int
    let color: Color
}

private struct TerritoryData: Identifiable {
    let id = UUID()
    let name: String
    let avgRisk: Double
    let count: Int
}

// MARK: - Dashboard Sub-views

private struct DashHeader: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Dashboard")
                .font(.title2).fontWeight(.bold)
                .foregroundStyle(AppTheme.wine)
            Text("Análisis de riesgo · Canal Tradicional")
                .font(.caption)
                .foregroundStyle(AppTheme.mutedText)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// Arc card — inspired by the Walk/Sleep cards in the design
private struct ArcKpiCard: View {
    let title: String
    let value: String
    let subtitle: String
    let pct: Double
    let icon: String
    let color: Color

    @State private var appeared = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text(title).font(.caption).foregroundStyle(AppTheme.mutedText)
                Spacer()
                Image(systemName: icon).font(.caption).foregroundStyle(color)
            }

            ZStack {
                // Track
                Circle()
                    .trim(from: 0.15, to: 0.85)
                    .stroke(color.opacity(0.12), style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(126))
                    .frame(width: 88, height: 88)

                // Fill
                Circle()
                    .trim(from: 0.15, to: 0.15 + (appeared ? 0.70 * CGFloat(pct) : 0))
                    .stroke(color, style: StrokeStyle(lineWidth: 10, lineCap: .round))
                    .rotationEffect(.degrees(126))
                    .frame(width: 88, height: 88)
                    .animation(.easeOut(duration: 1.1), value: appeared)

                VStack(spacing: 0) {
                    Text(value)
                        .font(.system(size: 20, weight: .black, design: .rounded))
                        .foregroundStyle(color)
                    Text(subtitle)
                        .font(.system(size: 9))
                        .foregroundStyle(AppTheme.mutedText)
                }
            }
            .frame(maxWidth: .infinity, alignment: .center)
        }
        .padding(14)
        .frame(maxWidth: .infinity)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: color.opacity(0.12), radius: 8, x: 0, y: 3)
        .onAppear { appeared = true }
    }
}

// Mini card with sparkline — inspired by Calories/Steps cards
private struct MiniKpiCard: View {
    let title: String
    let value: String
    let icon: String
    let color: Color
    let sparkValues: [Double]

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: icon).font(.caption).foregroundStyle(color)
                Text(title).font(.caption).foregroundStyle(AppTheme.mutedText)
            }

            // Sparkline
            if sparkValues.count > 1 {
                let maxV = sparkValues.max() ?? 1
                Chart {
                    ForEach(Array(sparkValues.enumerated()), id: \.offset) { i, v in
                        AreaMark(x: .value("i", i), y: .value("v", v))
                            .foregroundStyle(LinearGradient(colors: [color.opacity(0.35), color.opacity(0.05)],
                                                            startPoint: .top, endPoint: .bottom))
                            .interpolationMethod(.catmullRom)
                        LineMark(x: .value("i", i), y: .value("v", v))
                            .foregroundStyle(color)
                            .lineStyle(StrokeStyle(lineWidth: 2))
                            .interpolationMethod(.catmullRom)
                    }
                }
                .chartXAxis(.hidden)
                .chartYAxis(.hidden)
                .chartYScale(domain: 0...(maxV * 1.2))
                .frame(height: 44)
            }

            Text(value)
                .font(.system(size: 18, weight: .black, design: .rounded))
                .foregroundStyle(color)
        }
        .padding(14)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white)
        .cornerRadius(20)
        .shadow(color: color.opacity(0.10), radius: 8, x: 0, y: 3)
    }
}

private struct LegendPill: View {
    let color: Color; let label: String
    var body: some View {
        HStack(spacing: 3) {
            Circle().fill(color).frame(width: 6, height: 6)
            Text(label).font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
        }
    }
}

private struct TerritoryProgressRow: View {
    let data: TerritoryData
    private var barColor: Color {
        data.avgRisk >= 80 ? AppTheme.wine : data.avgRisk >= 50 ? AppTheme.softOrange : AppTheme.softGreen
    }
    @State private var appeared = false

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text(data.name).font(.caption).fontWeight(.semibold).lineLimit(1)
                Spacer()
                Text("\(Int(data.avgRisk))%")
                    .font(.caption).fontWeight(.bold).foregroundStyle(barColor)
                Text("· \(data.count) tiendas")
                    .font(.caption2).foregroundStyle(AppTheme.mutedText)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(barColor.opacity(0.10)).frame(height: 7)
                    Capsule()
                        .fill(LinearGradient(colors: [barColor.opacity(0.7), barColor],
                                             startPoint: .leading, endPoint: .trailing))
                        .frame(width: geo.size.width * CGFloat(appeared ? data.avgRisk / 100 : 0), height: 7)
                        .animation(.easeOut(duration: 0.9), value: appeared)
                }
            }
            .frame(height: 7)
        }
        .onAppear { appeared = true }
    }
}

private struct CriticalStoreRow: View {
    let client: StoreClient
    var body: some View {
        HStack(spacing: 14) {
            // Icon circle with % — like the workout icon circle
            ZStack {
                Circle()
                    .fill(client.riskColor.opacity(0.12))
                    .frame(width: 44, height: 44)
                Circle()
                    .trim(from: 0, to: CGFloat(client.riskPercentage / 100))
                    .stroke(client.riskColor, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .rotationEffect(.degrees(-90))
                    .frame(width: 44, height: 44)
                Text("\(Int(client.riskPercentage))%")
                    .font(.system(size: 9, weight: .black, design: .rounded))
                    .foregroundStyle(client.riskColor)
            }

            VStack(alignment: .leading, spacing: 3) {
                Text(client.storeName)
                    .font(.subheadline).fontWeight(.semibold).lineLimit(1)
                Text("\(client.territoryD) · \(client.transactions) tx · \(Int(client.uniBoxesSoldM)) cj")
                    .font(.caption2).foregroundStyle(AppTheme.mutedText).lineLimit(1)

                // Progress bar — like workout "150 Calories burn" bar
                GeometryReader { geo in
                    ZStack(alignment: .leading) {
                        Capsule().fill(client.riskColor.opacity(0.10)).frame(height: 4)
                        Capsule().fill(client.riskColor)
                            .frame(width: geo.size.width * CGFloat(client.riskPercentage / 100), height: 4)
                    }
                }
                .frame(height: 4)
            }

            Spacer()
            Image(systemName: "chevron.right")
                .font(.caption2).foregroundStyle(AppTheme.mutedText)
        }
        .padding(.vertical, 6)
    }
}

// MARK: - Reportes View

// Secciones del reporte — cada una se genera por separado con Gemini
enum ReportSection: String, CaseIterable {
    case resumen     = "Resumen Ejecutivo"
    case territorios = "Territorios"
    case subcanales  = "Subcanales"
    case criticos    = "Tiendas Críticas"
    case tendencia   = "Tendencia y Proyección"
    case acciones    = "Acciones Recomendadas"
}

struct ReporteSectionData: Identifiable {
    let id: ReportSection
    var content: String? = nil
    var isLoading: Bool = true
}

struct ReportesView: View {
    let clients: [StoreClient]

    @State private var sections: [ReporteSectionData] = ReportSection.allCases.map {
        ReporteSectionData(id: $0)
    }
    @State private var generatingAll = false

    // ── Stats calculados una vez ──────────────────────────────────
    private var total:      Int    { clients.count }
    private var critical:   Int    { clients.filter { $0.riskPercentage >= 80 }.count }
    private var medium:     Int    { clients.filter { $0.riskPercentage >= 50 && $0.riskPercentage < 80 }.count }
    private var low:        Int    { clients.filter { $0.riskPercentage < 50 }.count }
    private var avgRisk:    Double { clients.map(\.riskPercentage).reduce(0,+) / Double(max(total,1)) }
    private var avgBoxes:   Double { clients.map(\.uniBoxesSoldM).reduce(0,+) / Double(max(total,1)) }
    private var totalBoxes: Double { clients.map(\.uniBoxesSoldM).reduce(0,+) }
    private var totalTx:    Int    { clients.map(\.transactions).reduce(0,+) }
    private var volRiesgo:  Int    { Int(Double(critical)*avgBoxes*0.80 + Double(medium)*avgBoxes*0.40) }
    private var month:      String { clients.first?.calmonth ?? "—" }

    private var topTerritories: [(name: String, avg: Double, count: Int, critCount: Int)] {
        var result: [(name: String, avg: Double, count: Int, critCount: Int)] = []
        let grouped = Dictionary(grouping: clients, by: \.territoryD)
        for (key, vals) in grouped {
            let avg = vals.map(\.riskPercentage).reduce(0,+) / Double(vals.count)
            let crit = vals.filter { $0.riskPercentage >= 80 }.count
            result.append((name: key, avg: avg, count: vals.count, critCount: crit))
        }
        return Array(result.sorted { $0.avg > $1.avg }.prefix(10))
    }

    private var topSubchannels: [(name: String, avg: Double, count: Int)] {
        var result: [(name: String, avg: Double, count: Int)] = []
        let grouped = Dictionary(grouping: clients, by: \.comercialSubchannelD)
        for (key, vals) in grouped {
            let avg = vals.map(\.riskPercentage).reduce(0,+) / Double(vals.count)
            result.append((name: key, avg: avg, count: vals.count))
        }
        return Array(result.sorted { $0.avg > $1.avg }.prefix(5))
    }

    private var topCritical: [StoreClient] {
        Array(clients.sorted { $0.riskPercentage > $1.riskPercentage }.prefix(10))
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()

                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 20) {

                        // ── Header ────────────────────────────────────
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Reportes").font(.title2).fontWeight(.bold)
                                Text("Análisis completo · Periodo \(month)")
                                    .font(.caption).foregroundStyle(AppTheme.mutedText)
                            }
                            Spacer()
                            Button {
                                Task { await generateAllSections() }
                            } label: {
                                HStack(spacing: 6) {
                                    if generatingAll {
                                        ProgressView().tint(.white).scaleEffect(0.7)
                                    } else {
                                        Image(systemName: "sparkles").font(.caption)
                                    }
                                    Text(generatingAll ? "Generando..." : "Generar todo")
                                        .font(.caption).fontWeight(.semibold)
                                }
                                .foregroundStyle(.white)
                                .padding(.horizontal, 14).padding(.vertical, 8)
                                .background(AppTheme.wine)
                                .clipShape(Capsule())
                            }
                            .disabled(generatingAll)
                        }

                        // ── KPI strip ────────────────────────────────
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 10) {
                                ReporteKpi(label: "Total",       value: "\(total)",           color: AppTheme.wine)
                                ReporteKpi(label: "Críticos",    value: "\(critical)",         color: AppTheme.wine)
                                ReporteKpi(label: "Medios",      value: "\(medium)",           color: AppTheme.softOrange)
                                ReporteKpi(label: "Bajos",       value: "\(low)",              color: AppTheme.softGreen)
                                ReporteKpi(label: "Vol. Riesgo", value: "~\(volRiesgo) cj",    color: AppTheme.softOrange)
                                ReporteKpi(label: "Riesgo Prom", value: "\(Int(avgRisk))%",    color: AppTheme.wine)
                            }
                        }

                        // ── Secciones generadas por Gemini ────────────
                        ForEach(sections) { sec in
                            ReporteSectionCard(
                                section: sec.id,
                                content: sec.content,
                                isLoading: sec.isLoading,
                                onRefresh: {
                                    Task { await generateOne(sec.id) }
                                }
                            )
                        }

                    }
                    .padding(.horizontal, 16)
                    .padding(.top, 18)
                    .padding(.bottom, 32)
                }
            }
            .navigationBarHidden(true)
            .task {
                await generateAllSections()
            }
        }
    }

    // Genera todas las secciones secuencialmente (evita actor isolation issues)
    private func generateAllSections() async {
        generatingAll = true
        for section in ReportSection.allCases {
            await generateOne(section)
        }
        generatingAll = false
    }

    // Genera una sección por su ID — sin inout, actualiza @State directamente
    private func generateOne(_ sectionID: ReportSection) async {
        // Marcar como loading
        if let idx = sections.firstIndex(where: { $0.id == sectionID }) {
            sections[idx].isLoading = true
            sections[idx].content = nil
        }
        let prompt = buildPrompt(for: sectionID)
        var result: String
        do {
            result = try await ReportService.generate(prompt: prompt)
        } catch {
            result = buildFallback(for: sectionID)
        }
        if let idx = sections.firstIndex(where: { $0.id == sectionID }) {
            sections[idx].content = result
            sections[idx].isLoading = false
        }
    }

    // ── Prompts por sección ───────────────────────────────────────
    private func buildPrompt(for section: ReportSection) -> String {
        let terrLines: String = {
            var lines: [String] = []
            for t in topTerritories {
                lines.append("  \(t.name): \(String(format:"%.1f",t.avg))% riesgo prom, \(t.count) tiendas, \(t.critCount) críticas")
            }
            return lines.joined(separator: "\n")
        }()

        let subLines: String = {
            var lines: [String] = []
            for s in topSubchannels {
                lines.append("  \(s.name): \(String(format:"%.1f",s.avg))% riesgo prom, \(s.count) tiendas")
            }
            return lines.joined(separator: "\n")
        }()

        let critLines: String = {
            var lines: [String] = []
            for c in topCritical {
                lines.append("  \(c.territoryD) · \(c.comercialSubchannelD): \(String(format:"%.1f",c.riskPercentage))%, \(c.transactions) tx, \(Int(c.uniBoxesSoldM)) cajas")
            }
            return lines.joined(separator: "\n")
        }()

        let base = """
        Eres un agente experto en churn del Canal Tradicional de bebidas en México.
        Escribe en español profesional. Sin tablas. Sin markdown. Solo texto narrativo con párrafos.
        Periodo: \(month) | Total tiendas: \(total) | Críticas: \(critical) | Medias: \(medium) | Bajas: \(low)
        Riesgo promedio: \(String(format:"%.1f",avgRisk))% | Volumen en riesgo: ~\(volRiesgo) cajas | Total cajas: \(Int(totalBoxes)) | Transacciones: \(totalTx)
        """

        switch section {
        case .resumen:
            return base + """

            Escribe un RESUMEN EJECUTIVO completo de 3 párrafos:
            1. Estado general del portafolio: cuántas tiendas están en cada nivel, riesgo promedio y volumen en riesgo en cajas.
            2. Los territorios y subcanales más preocupantes con números reales.
            3. Conclusión sobre la urgencia de acción.
            Máximo 150 palabras. Tono ejecutivo y directo.
            """

        case .territorios:
            return base + """

            Top 10 territorios:
            \(terrLines)

            Escribe un análisis de TERRITORIOS en 3 párrafos:
            1. Los 3 territorios con mayor riesgo promedio: por qué son preocupantes (menciona los porcentajes y número de tiendas críticas reales).
            2. Territorios con mayor volumen absoluto de tiendas en riesgo.
            3. Recomendación específica de priorización por zona geográfica.
            Máximo 160 palabras. Menciona nombres reales de territorios.
            """

        case .subcanales:
            return base + """

            Top subcanales:
            \(subLines)

            Escribe un análisis de SUBCANALES en 2 párrafos:
            1. Cuáles subcanales concentran más riesgo y por qué son estratégicamente importantes.
            2. Recomendación de acción diferenciada por subcanal (qué hacer en cada uno).
            Máximo 120 palabras. Menciona nombres reales de subcanales.
            """

        case .criticos:
            return base + """

            Top 10 tiendas más críticas:
            \(critLines)

            Escribe un análisis de TIENDAS CRÍTICAS en 3 párrafos:
            1. Características comunes de las tiendas críticas (qué territorios y subcanales dominan, transacciones típicas).
            2. Señales de alerta que comparten estas tiendas.
            3. Plan de acción urgente para recuperar estas tiendas esta semana.
            Máximo 150 palabras.
            """

        case .tendencia:
            return base + """

            Escribe un análisis de TENDENCIA Y PROYECCIÓN en 3 párrafos:
            1. Proyección: si no se actúa, cuántas tiendas medias podrían escalar a crítico el próximo periodo (estimación razonada).
            2. Volumen en riesgo proyectado a 2 meses si la tendencia continúa.
            3. Factores estructurales que explican el riesgo elevado en este portafolio (subcanal, territorio, coolers, etc).
            Máximo 150 palabras. Usa los datos reales para fundamentar la proyección.
            """

        case .acciones:
            return base + """

            Escribe un plan de ACCIONES RECOMENDADAS en 4 párrafos numerados:
            1. Acción inmediata esta semana (con territorios y subcanales específicos).
            2. Acción preventiva para tiendas en estado medio.
            3. Acción estructural para reducir el riesgo a largo plazo.
            4. Métrica de éxito: cómo saber si las acciones funcionaron.
            Máximo 180 palabras. Acciones concretas y medibles.
            """
        }
    }

    private func buildFallback(for section: ReportSection) -> String {
        switch section {
        case .resumen:
            return "De \(total) tiendas analizadas en el periodo \(month), \(critical) se encuentran en estado Crítico (\(Int(Double(critical)/Double(max(total,1))*100))%) y \(medium) en estado Medio. El riesgo promedio global es de \(Int(avgRisk))%, con un volumen en riesgo estimado de ~\(volRiesgo) cajas. Se requiere intervención comercial inmediata en los territorios de mayor concentración de riesgo."
        case .territorios:
            let top3 = topTerritories.prefix(3).map { "\($0.name) (\(Int($0.avg))%)" }.joined(separator: ", ")
            return "Los territorios con mayor riesgo promedio son \(top3). Estos concentran la mayor proporción de tiendas críticas y requieren priorización en la ruta comercial de la próxima semana."
        case .subcanales:
            let top2 = topSubchannels.prefix(2).map { "\($0.name) (\(Int($0.avg))%)" }.joined(separator: " y ")
            return "Los subcanales \(top2) presentan el mayor riesgo promedio. Se recomienda activar promociones de recuperación de volumen dirigidas específicamente a estos segmentos."
        case .criticos:
            return "Las \(critical) tiendas en estado Crítico tienen alta probabilidad de dejar de comprar el próximo periodo. La mayoría concentra 0 transacciones y volumen mínimo. Se requiere visita comercial urgente con oferta de reactivación."
        case .tendencia:
            let proyeccion = Int(Double(medium) * 0.30)
            return "De continuar la tendencia actual, se estima que \(proyeccion) tiendas en estado Medio podrían escalar a Crítico el próximo periodo. El volumen en riesgo total podría superar las \(volRiesgo + proyeccion * Int(avgBoxes)) cajas si no se toman acciones preventivas."
        case .acciones:
            let topTerr = topTerritories.first?.name ?? "los territorios prioritarios"
            return "1. Esta semana: visitar las \(critical) tiendas críticas, comenzando por \(topTerr). 2. Preventivo: contactar las \(medium) tiendas medias con oferta de recuperación de volumen. 3. Estructural: revisar disponibilidad de coolers en tiendas sin equipo frío. 4. Éxito: reducir tiendas críticas en al menos 20% en el siguiente periodo."
        }
    }
}

// ── Servicio de reporte — llama a Gemini con prompt propio ───────────────────
struct ReportService {
    static let apiKey   = "AQ.Ab8RN6I9rNZmJs9iogE5uaY-R1_KIqPBlx3Kq9OhUbOKCs5r7g"
    static let endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=\(apiKey)"

    static func generate(prompt: String) async throws -> String {
        let body: [String: Any] = [
            "contents": [["parts": [["text": prompt]]]],
            "generationConfig": ["temperature": 0.4, "maxOutputTokens": 400]
        ]
        guard let url = URL(string: endpoint) else { throw GeminiError.invalidURL }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, response) = try await URLSession.shared.data(for: req)
        guard let http = response as? HTTPURLResponse, http.statusCode == 200 else { throw GeminiError.badResponse }

        guard
            let json       = try JSONSerialization.jsonObject(with: data) as? [String: Any],
            let candidates = json["candidates"] as? [[String: Any]],
            let content    = candidates.first?["content"] as? [String: Any],
            let parts      = content["parts"] as? [[String: Any]],
            let text       = parts.first?["text"] as? String
        else { throw GeminiError.parseError }

        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

// ── Card de cada sección del reporte ─────────────────────────────────────────
struct ReporteSectionCard: View {
    let section: ReportSection
    let content: String?
    let isLoading: Bool
    let onRefresh: () -> Void

    private var sectionIcon: String {
        switch section {
        case .resumen:      return "doc.text.fill"
        case .territorios:  return "map.fill"
        case .subcanales:   return "tag.fill"
        case .criticos:     return "exclamationmark.triangle.fill"
        case .tendencia:    return "chart.line.uptrend.xyaxis"
        case .acciones:     return "checkmark.seal.fill"
        }
    }

    private var sectionColor: Color {
        switch section {
        case .resumen:      return AppTheme.wine
        case .territorios:  return Color(red: 0.20, green: 0.45, blue: 0.85)
        case .subcanales:   return AppTheme.softOrange
        case .criticos:     return AppTheme.wine
        case .tendencia:    return Color(red: 0.50, green: 0.20, blue: 0.70)
        case .acciones:     return AppTheme.softGreen
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {

            // Header de sección
            HStack(spacing: 10) {
                ZStack {
                    Circle().fill(sectionColor.opacity(0.12)).frame(width: 36, height: 36)
                    Image(systemName: sectionIcon).font(.system(size: 14)).foregroundStyle(sectionColor)
                }
                Text(section.rawValue).font(.subheadline).fontWeight(.bold)
                Spacer()
                Button(action: onRefresh) {
                    Image(systemName: "arrow.clockwise")
                        .font(.caption).foregroundStyle(AppTheme.mutedText)
                }
                .disabled(isLoading)
            }

            Divider()

            // Contenido
            if isLoading {
                VStack(alignment: .leading, spacing: 8) {
                    ForEach(0..<4, id: \.self) { i in
                        RoundedRectangle(cornerRadius: 3)
                            .fill(Color.gray.opacity(0.12))
                            .frame(height: 11)
                            .frame(maxWidth: i == 3 ? .infinity * 0.6 : .infinity)
                    }
                }
            } else if let text = content {
                Text(text)
                    .font(.subheadline)
                    .lineSpacing(5)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(16)
        .background(Color.white)
        .cornerRadius(18)
        .shadow(color: sectionColor.opacity(0.08), radius: 8, x: 0, y: 3)
        .overlay(
            RoundedRectangle(cornerRadius: 18)
                .strokeBorder(sectionColor.opacity(0.15), lineWidth: 1)
        )
    }
}

// ── KPI chip del strip ────────────────────────────────────────────────────────
private struct ReporteKpi: View {
    let label: String
    let value: String
    let color: Color

    var body: some View {
        VStack(spacing: 3) {
            Text(value).font(.system(size: 15, weight: .black, design: .rounded)).foregroundStyle(color)
            Text(label).font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .background(color.opacity(0.07))
        .cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(color.opacity(0.15), lineWidth: 1))
    }
}

// MARK: - Encuestas View

// ── 20 encuestas mock ────────────────────────────────────────────────────────

struct Encuesta: Identifiable {
    let id = UUID()
    let tienda: String
    let territorio: String
    let fecha: String
    let satisfaccion: Int        // 0-10
    let pedidoCompleto: Bool
    let preventistaPuntual: Bool
    let coolerFuncional: Bool
    let recomendariaRepartidor: Bool
    let recomendariaProveedor: Bool
    let comentario: String

    var nivel: String {
        if satisfaccion >= 9 { return "Bueno" }
        if satisfaccion >= 7 { return "Neutral" }
        return "Malo"
    }
    var nivelColor: Color {
        if satisfaccion >= 9 { return AppTheme.softGreen }
        if satisfaccion >= 7 { return Color(red:1.00,green:0.75,blue:0.00) }
        return AppTheme.wine
    }
    var nivelEmoji: String {
        if satisfaccion >= 9 { return "😄" }
        if satisfaccion >= 7 { return "😐" }
        return "😢"
    }
}

private let mockEncuestas: [Encuesta] = [
    Encuesta(tienda:"Abarrotes La Esquina",   territorio:"Jalisco",   fecha:"02/02/26", satisfaccion:10, pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Excelente servicio, llegó a tiempo y completo."),
    Encuesta(tienda:"Tienda Los Compadres",   territorio:"Saltillo",  fecha:"02/02/26", satisfaccion:3,  pedidoCompleto:false, preventistaPuntual:false, coolerFuncional:false, recomendariaRepartidor:false, recomendariaProveedor:false, comentario:"Pedido incompleto y cooler descompuesto."),
    Encuesta(tienda:"Super Don Lupe",         territorio:"Durango",   fecha:"03/02/26", satisfaccion:9,  pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Muy buen servicio, sin quejas."),
    Encuesta(tienda:"Mini Súper Lupita",      territorio:"Culiacán",  fecha:"03/02/26", satisfaccion:2,  pedidoCompleto:false, preventistaPuntual:false, coolerFuncional:false, recomendariaRepartidor:false, recomendariaProveedor:false, comentario:"Muy mala experiencia, no volvería a pedir."),
    Encuesta(tienda:"Abarrotes El Güero",     territorio:"Jalisco",   fecha:"04/02/26", satisfaccion:7,  pedidoCompleto:true,  preventistaPuntual:false, coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Bien, aunque el repartidor llegó tarde."),
    Encuesta(tienda:"Tienda Doña Chayo",      territorio:"Reynosa",   fecha:"04/02/26", satisfaccion:10, pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Todo perfecto, muy recomendado."),
    Encuesta(tienda:"El Recreo de Martínez",  territorio:"Monclova",  fecha:"05/02/26", satisfaccion:4,  pedidoCompleto:false, preventistaPuntual:true,  coolerFuncional:false, recomendariaRepartidor:false, recomendariaProveedor:false, comentario:"Faltaron productos y el cooler sin funcionar."),
    Encuesta(tienda:"Abarrotes Don Memo",     territorio:"Durango",   fecha:"05/02/26", satisfaccion:8,  pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Bien en general, sin quejas."),
    Encuesta(tienda:"La Tiendita de Rosita",  territorio:"Jalisco",   fecha:"06/02/26", satisfaccion:7,  pedidoCompleto:true,  preventistaPuntual:false, coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:false, comentario:"Regular, el repartidor tardó bastante."),
    Encuesta(tienda:"Tienda El Farolito",     territorio:"Saltillo",  fecha:"06/02/26", satisfaccion:9,  pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Siempre puntual y completo."),
    Encuesta(tienda:"Abarrotes La Paloma",    territorio:"Mazatlán",  fecha:"07/02/26", satisfaccion:1,  pedidoCompleto:false, preventistaPuntual:false, coolerFuncional:false, recomendariaRepartidor:false, recomendariaProveedor:false, comentario:"Pésimo, no llegó el pedido."),
    Encuesta(tienda:"Super Toño",             territorio:"Culiacán",  fecha:"07/02/26", satisfaccion:8,  pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:false, recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Todo bien menos el cooler."),
    Encuesta(tienda:"Tienda Los Amigos",      territorio:"Jalisco",   fecha:"08/02/26", satisfaccion:6,  pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:false, recomendariaProveedor:false, comentario:"Servicio regular, esperaba más."),
    Encuesta(tienda:"Abarrotes Hernández",    territorio:"Monclova",  fecha:"08/02/26", satisfaccion:10, pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Excelente como siempre."),
    Encuesta(tienda:"La Bodega de Carmen",    territorio:"Reynosa",   fecha:"09/02/26", satisfaccion:4,  pedidoCompleto:false, preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:false, recomendariaProveedor:false, comentario:"Pedido incompleto por segunda vez."),
    Encuesta(tienda:"Tienda El Oasis",        territorio:"Durango",   fecha:"09/02/26", satisfaccion:8,  pedidoCompleto:true,  preventistaPuntual:false, coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Buen servicio aunque tardó."),
    Encuesta(tienda:"Abarrotes El Progreso",  territorio:"Saltillo",  fecha:"10/02/26", satisfaccion:7,  pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:false, recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Cooler sin funcionar desde hace 2 semanas."),
    Encuesta(tienda:"Minisuper Los Primos",   territorio:"Jalisco",   fecha:"10/02/26", satisfaccion:9,  pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Todo excelente, sin comentarios negativos."),
    Encuesta(tienda:"Tienda Don Beto",        territorio:"Mazatlán",  fecha:"11/02/26", satisfaccion:5,  pedidoCompleto:true,  preventistaPuntual:false, coolerFuncional:false, recomendariaRepartidor:false, recomendariaProveedor:false, comentario:"Tarde y sin cooler funcional."),
    Encuesta(tienda:"Super Ramírez",          territorio:"Culiacán",  fecha:"11/02/26", satisfaccion:9,  pedidoCompleto:true,  preventistaPuntual:true,  coolerFuncional:true,  recomendariaRepartidor:true,  recomendariaProveedor:true,  comentario:"Muy buena atención."),
]

struct EncuestasView: View {
    @State private var selectedIdx: Int? = nil

    // ── Stats calculados ─────────────────────────────────────────
    private var total: Int { mockEncuestas.count }
    private var avgSat: Double { Double(mockEncuestas.map(\.satisfaccion).reduce(0,+)) / Double(total) }
    private var satPct: Double { avgSat / 10.0 * 100 } // 0-10 → 0-100%

    private var cntBueno:   Int { mockEncuestas.filter { $0.satisfaccion >= 9 }.count }
    private var cntNeutral: Int { mockEncuestas.filter { $0.satisfaccion >= 7 && $0.satisfaccion < 9 }.count }
    private var cntMalo:    Int { mockEncuestas.filter { $0.satisfaccion < 7 }.count }

    private func pct(_ keyPath: KeyPath<Encuesta, Bool>) -> Int {
        Int(Double(mockEncuestas.filter { $0[keyPath: keyPath] }.count) / Double(total) * 100)
    }

    private var porTerritorio: [(nombre: String, avg: Double, count: Int)] {
        var result: [(nombre: String, avg: Double, count: Int)] = []
        let g = Dictionary(grouping: mockEncuestas, by: \.territorio)
        for (k, v) in g {
            let avg = Double(v.map(\.satisfaccion).reduce(0,+)) / Double(v.count)
            result.append((nombre: k, avg: avg, count: v.count))
        }
        return result.sorted { $0.avg > $1.avg }
    }

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 20) {

                        // ── Header ───────────────────────────────────
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Encuestas").font(.title2).fontWeight(.bold)
                            Text("\(total) respuestas · Periodo 02/2026")
                                .font(.caption).foregroundStyle(AppTheme.mutedText)
                        }

                        // ── Medidor central ──────────────────────────
                        SatisfactionGauge(
                            pct: satPct,
                            distBueno:   cntBueno,
                            distNeutral: cntNeutral,
                            distMalo:    cntMalo
                        )
                        .frame(height: 220)
                        .padding(.horizontal, 20)

                        // ── KPI strip ────────────────────────────────
                        HStack(spacing: 10) {
                            EncKpi(label: "Encuestas",  value: "\(total)",           icon: "doc.text.fill",    color: AppTheme.wine)
                            EncKpi(label: "Bueno",      value: "\(cntBueno)",        icon: "face.smiling",     color: AppTheme.softGreen)
                            EncKpi(label: "Neutral",    value: "\(cntNeutral)",      icon: "minus.circle",     color: Color(red:1.00,green:0.75,blue:0.00))
                            EncKpi(label: "Malo",       value: "\(cntMalo)",         icon: "exclamationmark.circle", color: AppTheme.wine)
                        }

                        // ── Distribución Bueno/Neutral/Malo ──────────
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Distribución de satisfacción")
                                .font(.subheadline).fontWeight(.bold)
                            ForEach([
                                ("😄 Bueno (9-10)",   cntBueno,   AppTheme.softGreen),
                                ("😐 Neutral (7-8)",  cntNeutral, Color(red:1.00,green:0.75,blue:0.00)),
                                ("😢 Malo (0-6)",     cntMalo,    AppTheme.wine),
                            ], id: \.0) { item in
                                HStack(spacing: 8) {
                                    Text(item.0).font(.caption).frame(width: 110, alignment: .leading)
                                    GeometryReader { geo in
                                        ZStack(alignment: .leading) {
                                            Capsule().fill(item.2.opacity(0.12)).frame(height: 8)
                                            Capsule().fill(item.2)
                                                .frame(width: total > 0 ? geo.size.width * CGFloat(item.1) / CGFloat(total) : 0, height: 8)
                                        }
                                    }
                                    .frame(height: 8)
                                    Text("\(item.1)").font(.caption2).foregroundStyle(AppTheme.mutedText).frame(width: 20)
                                }
                            }
                        }
                        .padding(16).modernCard()

                        // ── Preguntas clave ──────────────────────────
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Preguntas clave").font(.subheadline).fontWeight(.bold)
                            PreguntaRow(pregunta: "¿El pedido llegó completo?",          pct: Double(pct(\.pedidoCompleto)),           color: AppTheme.softGreen)
                            PreguntaRow(pregunta: "¿El preventista fue puntual?",        pct: Double(pct(\.preventistaPuntual)),       color: AppTheme.softGreen)
                            PreguntaRow(pregunta: "¿El cooler estaba funcional?",        pct: Double(pct(\.coolerFuncional)),          color: AppTheme.softOrange)
                            PreguntaRow(pregunta: "¿Recomendarías al repartidor?",       pct: Double(pct(\.recomendariaRepartidor)),   color: AppTheme.softOrange)
                            PreguntaRow(pregunta: "¿Recomendarías al proveedor?",        pct: Double(pct(\.recomendariaProveedor)),    color: AppTheme.wine)
                        }
                        .padding(16).modernCard()

                        // ── Por territorio ───────────────────────────
                        VStack(alignment: .leading, spacing: 12) {
                            Text("Satisfacción por territorio")
                                .font(.subheadline).fontWeight(.bold)
                            ForEach(porTerritorio, id: \.nombre) { t in
                                HStack(spacing: 10) {
                                    Text(t.nombre).font(.caption).lineLimit(1).frame(maxWidth: 110, alignment: .leading)
                                    GeometryReader { geo in
                                        ZStack(alignment: .leading) {
                                            Capsule().fill(gaugeColor(t.avg/10*100).opacity(0.12)).frame(height: 7)
                                            Capsule().fill(gaugeColor(t.avg/10*100))
                                                .frame(width: geo.size.width * CGFloat(t.avg/10), height: 7)
                                        }
                                    }
                                    .frame(height: 7)
                                    Text(String(format:"%.1f",t.avg)).font(.caption2).fontWeight(.bold)
                                        .foregroundStyle(gaugeColor(t.avg/10*100)).frame(width: 24)
                                    Text("(\(t.count))").font(.caption2).foregroundStyle(AppTheme.mutedText).frame(width: 22)
                                }
                            }
                        }
                        .padding(16).modernCard()

                        // ── Lista de encuestas ───────────────────────
                        VStack(alignment: .leading, spacing: 10) {
                            Text("Últimas encuestas").font(.subheadline).fontWeight(.bold)
                            ForEach(Array(mockEncuestas.enumerated()), id: \.offset) { i, enc in
                                Button { selectedIdx = selectedIdx == i ? nil : i } label: {
                                    EncuestaRow(enc: enc, expanded: selectedIdx == i)
                                }
                                .buttonStyle(.plain)
                                if i < mockEncuestas.count - 1 { Divider() }
                            }
                        }
                        .padding(16).modernCard()

                    }
                    .padding(.horizontal, 16).padding(.top, 18).padding(.bottom, 32)
                }
            }
            .navigationBarHidden(true)
        }
    }

    private func gaugeColor(_ pct: Double) -> Color {
        if pct >= 70 { return AppTheme.softGreen }
        if pct >= 45 { return AppTheme.softOrange }
        return AppTheme.wine
    }
}

// ── Satisfaction Gauge ────────────────────────────────────────────────────────
// Donut dinámico: verde=Bueno(9-10), amarillo=Neutral(7-8), rojo=Malo(0-6)
struct SatisfactionGauge: View {
    let pct: Double
    let distBueno:   Int
    let distNeutral: Int
    let distMalo:    Int

    @State private var appeared = false

    private var totalEnc: Int { distBueno + distNeutral + distMalo }

    private func angle(_ count: Int) -> Double {
        guard totalEnc > 0 else { return 0 }
        return 360.0 * Double(count) / Double(totalEnc)
    }

    private var sectors: [(color: Color, degrees: Double, emoji: String)] {[
        (AppTheme.wine,                            angle(distMalo),    "😢"),
        (Color(red:1.00,green:0.75,blue:0.00),    angle(distNeutral), "😐"),
        (AppTheme.softGreen,                       angle(distBueno),   "😄"),
    ]}

    private var needleAngle: Double {
        let animPct = appeared ? pct : 0
        return -130 + (260 * animPct / 100)
    }

    private var label: String {
        if pct >= 70 { return "Bueno" }
        if pct >= 45 { return "Neutral" }
        return "Malo"
    }

    private var labelColor: Color {
        if pct >= 70 { return AppTheme.softGreen }
        if pct >= 45 { return Color(red:0.80,green:0.60,blue:0.00) }
        return AppTheme.wine
    }

    var body: some View {
        GeometryReader { geo in
            let size   = min(geo.size.width, geo.size.height)
            let center = CGPoint(x: geo.size.width / 2, y: geo.size.height / 2)
            let radius = size / 2

            ZStack {
                // ── Donut dinámico proporcional ───────────────
                DynamicDonut(sectors: sectors, appeared: appeared)

                // ── Caritas en cada sector visible ────────────
                DynamicEmojis(sectors: sectors, center: center, radius: radius, size: size)

                // ── Borde exterior ────────────────────────────
                Circle()
                    .stroke(Color(red:0.22,green:0.20,blue:0.55), lineWidth: 6)

                // ── Círculo interior blanco ───────────────────
                Circle()
                    .fill(Color.white)
                    .frame(width: size * 0.46, height: size * 0.46)

                // ── Aguja ─────────────────────────────────────
                NeedleShape()
                    .fill(Color(red:0.15,green:0.30,blue:0.65))
                    .frame(width: size * 0.03, height: size * 0.38)
                    .offset(y: -size * 0.09)
                    .rotationEffect(.degrees(needleAngle))
                    .animation(.spring(response: 1.2, dampingFraction: 0.6), value: appeared)

                // ── Punto central ─────────────────────────────
                Circle()
                    .fill(Color(red:0.15,green:0.30,blue:0.65))
                    .frame(width: size * 0.06, height: size * 0.06)

                // ── Texto central con marco blanco ────────────
                VStack(spacing: 1) {
                    Text(label)
                        .font(.system(size: size * 0.050, weight: .bold))
                        .foregroundStyle(labelColor)
                    Text(String(format: "%.0f%%", pct))
                        .font(.system(size: size * 0.09, weight: .black, design: .rounded))
                        .foregroundStyle(labelColor)
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 5)
                .background(
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.white.opacity(0.92))
                        .shadow(color: .black.opacity(0.10), radius: 4, x: 0, y: 2)
                )
            }
        }
        .onAppear { withAnimation(.easeOut(duration: 1.0)) { appeared = true } }
    }
}

// Dibuja el donut con sectores proporcionales a los conteos reales
// Arranca desde la izquierda (-180°) y va en sentido horario
// para que coincida con el sistema -130°/+130° de la aguja
struct DynamicDonut: View {
    let sectors: [(color: Color, degrees: Double, emoji: String)]
    let appeared: Bool

    var body: some View {
        Canvas { ctx, size in
            let center = CGPoint(x: size.width / 2, y: size.height / 2)
            let radius = min(size.width, size.height) / 2
            // Arrancamos en -180° (izquierda) para que malo=izq, bueno=der
            var startDeg: Double = -180

            for sector in sectors {
                guard sector.degrees > 0 else { continue }
                let endDeg = startDeg + (appeared ? sector.degrees : 0)

                var path = Path()
                path.move(to: center)
                path.addArc(center: center, radius: radius,
                            startAngle: .degrees(startDeg),
                            endAngle: .degrees(endDeg),
                            clockwise: false)
                path.closeSubpath()
                ctx.fill(path, with: .color(sector.color))

                startDeg = endDeg
            }
        }
        .animation(.easeOut(duration: 1.0), value: appeared)
    }
}

// Coloca emojis en el centro de cada sector visible
struct DynamicEmojis: View {
    let sectors: [(color: Color, degrees: Double, emoji: String)]
    let center: CGPoint
    let radius: CGFloat
    let size: CGFloat

    private struct SectorMid: Identifiable {
        let id: Int
        let midDeg: Double
        let emoji: String
        let visible: Bool
    }

    private var mids: [SectorMid] {
        let total = sectors.map(\.degrees).reduce(0, +)
        var result: [SectorMid] = []
        var startDeg: Double = -180  // mismo origen que DynamicDonut
        for (i, s) in sectors.enumerated() {
            let mid = startDeg + s.degrees / 2
            result.append(SectorMid(
                id: i,
                midDeg: mid,
                emoji: s.emoji,
                visible: s.degrees / max(total, 1) > 0.05
            ))
            startDeg += s.degrees
        }
        return result
    }

    var body: some View {
        ZStack {
            ForEach(mids) { m in
                if m.visible {
                    let midRad = m.midDeg * .pi / 180
                    let dist   = radius * 0.68
                    let ex = center.x + dist * CGFloat(cos(midRad))
                    let ey = center.y + dist * CGFloat(sin(midRad))
                    Text(m.emoji)
                        .font(.system(size: size * 0.09))
                        .shadow(color: .black.opacity(0.15), radius: 2, x: 0, y: 1)
                        .position(x: ex, y: ey)
                }
            }
        }
    }
}

struct ArcSlice: Shape {
    let startAngle: Double
    let endAngle: Double

    func path(in rect: CGRect) -> Path {
        let center = CGPoint(x: rect.midX, y: rect.midY)
        let radius = min(rect.width, rect.height) / 2
        var p = Path()
        p.move(to: center)
        p.addArc(center: center, radius: radius,
                 startAngle: .degrees(startAngle), endAngle: .degrees(endAngle),
                 clockwise: false)
        p.closeSubpath()
        return p
    }
}

struct NeedleShape: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        p.move(to: CGPoint(x: rect.midX, y: rect.maxY))
        p.addLine(to: CGPoint(x: rect.midX - rect.width/2, y: rect.midY))
        p.addLine(to: CGPoint(x: rect.midX, y: rect.minY))
        p.addLine(to: CGPoint(x: rect.midX + rect.width/2, y: rect.midY))
        p.closeSubpath()
        return p
    }
}

// ── Encuesta Row ──────────────────────────────────────────────────────────────
private struct EncuestaRow: View {
    let enc: Encuesta
    let expanded: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                // Score badge
                ZStack {
                    Circle().fill(enc.nivelColor.opacity(0.12)).frame(width: 36, height: 36)
                    Text("\(enc.satisfaccion)")
                        .font(.system(size: 13, weight: .black, design: .rounded))
                        .foregroundStyle(enc.nivelColor)
                }

                VStack(alignment: .leading, spacing: 2) {
                    HStack(spacing: 4) {
                        Text(enc.tienda).font(.caption).fontWeight(.semibold).lineLimit(1)
                        Text(enc.nivelEmoji).font(.caption)
                    }
                    Text("\(enc.territorio) · \(enc.fecha) · \(enc.nivel)")
                        .font(.caption2).foregroundStyle(enc.nivelColor)
                }
                Spacer()
                Image(systemName: expanded ? "chevron.up" : "chevron.down")
                    .font(.caption2).foregroundStyle(AppTheme.mutedText)
            }

            if expanded {
                Text(enc.comentario)
                    .font(.caption).foregroundStyle(.secondary).lineSpacing(3)
                    .padding(.leading, 4)

                HStack(spacing: 6) {
                    CheckPill(label: "Pedido",      ok: enc.pedidoCompleto)
                    CheckPill(label: "Puntual",     ok: enc.preventistaPuntual)
                    CheckPill(label: "Cooler",      ok: enc.coolerFuncional)
                    CheckPill(label: "Repartidor",  ok: enc.recomendariaRepartidor)
                    CheckPill(label: "Proveedor",   ok: enc.recomendariaProveedor)
                }
                .padding(.leading, 4)
            }
        }
        .padding(.vertical, 4)
    }
}

private struct CheckPill: View {
    let label: String; let ok: Bool
    var body: some View {
        HStack(spacing: 3) {
            Image(systemName: ok ? "checkmark" : "xmark")
                .font(.system(size: 8, weight: .bold))
            Text(label).font(.system(size: 9))
        }
        .foregroundStyle(ok ? AppTheme.softGreen : AppTheme.wine)
        .padding(.horizontal, 6).padding(.vertical, 3)
        .background((ok ? AppTheme.softGreen : AppTheme.wine).opacity(0.10))
        .clipShape(Capsule())
    }
}

// MARK: - Shared Encuestas Components

struct EncKpi: View {
    let label: String
    let value: String
    let icon: String
    let color: Color

    var body: some View {
        VStack(spacing: 5) {
            Image(systemName: icon).font(.system(size: 16)).foregroundStyle(color)
            Text(value).font(.system(size: 15, weight: .black, design: .rounded)).foregroundStyle(color)
            Text(label).font(.system(size: 9)).foregroundStyle(AppTheme.mutedText)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(color.opacity(0.07))
        .cornerRadius(14)
        .overlay(RoundedRectangle(cornerRadius: 14).strokeBorder(color.opacity(0.15), lineWidth: 1))
    }
}

struct PreguntaRow: View {
    let pregunta: String
    let pct: Double
    let color: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            HStack {
                Text(pregunta).font(.caption).lineLimit(1).minimumScaleFactor(0.8)
                Spacer()
                Text("\(Int(pct))%").font(.caption).fontWeight(.bold).foregroundStyle(color)
            }
            GeometryReader { geo in
                ZStack(alignment: .leading) {
                    Capsule().fill(color.opacity(0.10)).frame(height: 6)
                    Capsule().fill(color)
                        .frame(width: geo.size.width * CGFloat(pct / 100), height: 6)
                }
            }
            .frame(height: 6)
        }
    }
}

// MARK: - Placeholder

struct PlaceholderView: View {
    let title: String
    let subtitle: String
    let icon: String

    var body: some View {
        NavigationStack {
            ZStack {
                AppTheme.appBackground.ignoresSafeArea()
                VStack(spacing: 18) {
                    ZStack {
                        Circle().fill(AppTheme.wine.opacity(0.12)).frame(width: 80, height: 80)
                        Image(systemName: icon).font(.system(size: 32, weight: .bold)).foregroundStyle(AppTheme.wine)
                    }
                    Text(title).font(.title2).fontWeight(.bold)
                    Text(subtitle).font(.subheadline).foregroundStyle(AppTheme.mutedText)
                        .multilineTextAlignment(.center).padding(.horizontal, 28)
                }
                .padding(24).modernCard().padding(24)
            }
            .navigationBarHidden(true)
        }
    }
}

#Preview {
    MainTabView()
}
